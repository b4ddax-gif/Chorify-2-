package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.MatchHistoryRepository
import com.example.data.MatchRecordEntity
import com.example.data.SettingsRepository
import com.example.model.AppThemeOption
import com.example.model.GameRulesEngine
import com.example.model.GameScreen
import com.example.model.GameSettings
import com.example.model.Player
import com.example.model.Role
import com.example.model.RoundSummary
import com.example.util.SoundCue
import com.example.util.SoundHapticManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PassAndPlayPrivateView(
    val playerId: Int,
    val playerName: String,
    val cornerLabel: String,
    val role: Role
)

data class PublicCourtAnnouncement(
    val roundNumber: Int,
    val totalRounds: Int,
    val rajaPlayer: Player,
    val policePlayer: Player
)

data class ChorifyUiState(
    val currentScreen: GameScreen = GameScreen.HOME,
    val setupPlayerNames: List<String> = listOf("Player 1", "Player 2", "Player 3", "Player 4"),
    val selectedTotalRounds: Int = 5,
    val selectedTimerSeconds: Int = 30,
    val players: List<Player> = emptyList(),
    val currentRound: Int = 1,
    // Pass & Play state: only the currently active player index is tracked,
    // and the role is ONLY exposed inside activePrivateReveal while the player holds reveal
    val currentPassPlayerIndex: Int = 0,
    val isRoleCurrentlyRevealed: Boolean = false,
    val activePrivateReveal: PassAndPlayPrivateView? = null,
    // Public Role & Police Guess Phase
    val publicAnnouncement: PublicCourtAnnouncement? = null,
    val remainingTimerSeconds: Int = 30,
    val selectedSuspectPlayerId: Int? = null,
    val isGuessLocked: Boolean = false,
    // Round Result & Scoreboard (populated ONLY after Police confirms guess or timer expires)
    val latestRoundSummary: RoundSummary? = null,
    val roundHistory: List<RoundSummary> = emptyList(),
    // Privacy Shield when app goes to background or multi-window pause
    val isPrivacyShieldActive: Boolean = false
)

class ChorifyViewModel(
    private val matchHistoryRepository: MatchHistoryRepository,
    private val settingsRepository: SettingsRepository,
    private val soundHapticManager: SoundHapticManager? = null
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChorifyUiState())
    val uiState: StateFlow<ChorifyUiState> = _uiState.asStateFlow()

    val settingsState: StateFlow<GameSettings> = settingsRepository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = GameSettings()
    )

    val matchHistoryState: StateFlow<List<MatchRecordEntity>> = matchHistoryRepository.allMatches.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Private in-memory vault for current round's role assignments.
    // Never exposed directly to ChorifyUiState so UI cannot accidentally leak Mantri or Chor.
    private var secretRoundAssignments: Map<Int, Role> = emptyMap()

    private var countdownJob: Job? = null

    private val cornerLabels = listOf(
        "NORTH-WEST CORNER",
        "NORTH-EAST CORNER",
        "SOUTH-WEST CORNER",
        "SOUTH-EAST CORNER"
    )

    fun playCue(cue: SoundCue) {
        val currentSettings = settingsState.value
        soundHapticManager?.triggerCue(
            cue = cue,
            soundEnabled = currentSettings.soundEnabled,
            vibrationEnabled = currentSettings.vibrationEnabled
        )
    }

    fun navigateTo(screen: GameScreen) {
        playCue(SoundCue.BUTTON_CLICK)
        if (screen == GameScreen.HOME) {
            stopCountdown()
            secretRoundAssignments = emptyMap()
        }
        _uiState.update {
            it.copy(
                currentScreen = screen,
                isRoleCurrentlyRevealed = false,
                activePrivateReveal = null
            )
        }
    }

    fun openPlayerSetup() {
        playCue(SoundCue.BUTTON_CLICK)
        _uiState.update {
            it.copy(
                currentScreen = GameScreen.PLAYER_SETUP,
                isRoleCurrentlyRevealed = false,
                activePrivateReveal = null
            )
        }
    }

    fun updatePlayerName(index: Int, newName: String) {
        if (index !in 0..3) return
        _uiState.update { state ->
            val updated = state.setupPlayerNames.toMutableList()
            updated[index] = newName.take(18)
            state.copy(setupPlayerNames = updated)
        }
    }

    fun selectTotalRounds(rounds: Int) {
        if (rounds !in listOf(3, 5, 10)) return
        playCue(SoundCue.BUTTON_CLICK)
        _uiState.update { it.copy(selectedTotalRounds = rounds) }
    }

    fun selectTimerSeconds(seconds: Int) {
        if (seconds !in listOf(15, 30, 60)) return
        playCue(SoundCue.BUTTON_CLICK)
        _uiState.update { it.copy(selectedTimerSeconds = seconds) }
    }

    fun startNewMatch() {
        playCue(SoundCue.CARD_SHUFFLE)
        stopCountdown()
        val currentNames = _uiState.value.setupPlayerNames.mapIndexed { idx, raw ->
            val trimmed = raw.trim()
            if (trimmed.isEmpty()) "Player ${idx + 1}" else trimmed
        }
        val initialPlayers = currentNames.mapIndexed { idx, name ->
            Player(
                id = idx,
                name = name,
                cornerLabel = cornerLabels[idx],
                totalScore = 0,
                roundsWon = 0,
                policeSuccessCount = 0,
                chorEscapeCount = 0
            )
        }
        _uiState.update {
            it.copy(
                setupPlayerNames = currentNames,
                players = initialPlayers,
                currentRound = 1,
                roundHistory = emptyList(),
                latestRoundSummary = null
            )
        }
        beginRoundDistribution(roundNumber = 1, currentPlayers = initialPlayers)
    }

    fun playAgainSamePlayers() {
        playCue(SoundCue.CARD_SHUFFLE)
        stopCountdown()
        val resetPlayers = _uiState.value.players.map {
            it.copy(
                totalScore = 0,
                roundsWon = 0,
                policeSuccessCount = 0,
                chorEscapeCount = 0
            )
        }
        if (resetPlayers.size == 4) {
            _uiState.update {
                it.copy(
                    players = resetPlayers,
                    currentRound = 1,
                    roundHistory = emptyList(),
                    latestRoundSummary = null
                )
            }
            beginRoundDistribution(roundNumber = 1, currentPlayers = resetPlayers)
        } else {
            startNewMatch()
        }
    }

    private fun beginRoundDistribution(roundNumber: Int, currentPlayers: List<Player>) {
        stopCountdown()
        secretRoundAssignments = GameRulesEngine.distributeRoles(currentPlayers.map { it.id })

        val rajaId = secretRoundAssignments.entries.first { it.value == Role.RAJA }.key
        val policeId = secretRoundAssignments.entries.first { it.value == Role.POLICE }.key

        val announcement = PublicCourtAnnouncement(
            roundNumber = roundNumber,
            totalRounds = _uiState.value.selectedTotalRounds,
            rajaPlayer = currentPlayers.first { it.id == rajaId },
            policePlayer = currentPlayers.first { it.id == policeId }
        )

        _uiState.update {
            it.copy(
                currentScreen = GameScreen.SECRET_ROLE_PASS,
                currentRound = roundNumber,
                currentPassPlayerIndex = 0,
                isRoleCurrentlyRevealed = false,
                activePrivateReveal = null,
                publicAnnouncement = announcement,
                selectedSuspectPlayerId = null,
                isGuessLocked = false,
                latestRoundSummary = null,
                remainingTimerSeconds = it.selectedTimerSeconds
            )
        }
    }

    fun revealCurrentPlayerRole() {
        val state = _uiState.value
        if (state.currentScreen != GameScreen.SECRET_ROLE_PASS) return
        val player = state.players.getOrNull(state.currentPassPlayerIndex) ?: return
        val assignedRole = secretRoundAssignments[player.id] ?: return

        playCue(SoundCue.ROLE_REVEAL)
        _uiState.update {
            it.copy(
                isRoleCurrentlyRevealed = true,
                activePrivateReveal = PassAndPlayPrivateView(
                    playerId = player.id,
                    playerName = player.name,
                    cornerLabel = player.cornerLabel,
                    role = assignedRole
                )
            )
        }
    }

    fun hideRoleAndAdvancePlayer() {
        val state = _uiState.value
        if (state.currentScreen != GameScreen.SECRET_ROLE_PASS) return

        playCue(SoundCue.ROLE_HIDE)
        val nextIndex = state.currentPassPlayerIndex + 1

        // Immediately scrub the private role from UI state before transitioning
        if (nextIndex < 4) {
            _uiState.update {
                it.copy(
                    currentPassPlayerIndex = nextIndex,
                    isRoleCurrentlyRevealed = false,
                    activePrivateReveal = null
                )
            }
        } else {
            _uiState.update {
                it.copy(
                    currentScreen = GameScreen.PUBLIC_ROLE_DISPLAY,
                    currentPassPlayerIndex = 0,
                    isRoleCurrentlyRevealed = false,
                    activePrivateReveal = null
                )
            }
        }
    }

    fun startPoliceGuessPhase() {
        playCue(SoundCue.BUTTON_CLICK)
        val timerSec = _uiState.value.selectedTimerSeconds
        _uiState.update {
            it.copy(
                currentScreen = GameScreen.POLICE_GUESS,
                remainingTimerSeconds = timerSec,
                selectedSuspectPlayerId = null,
                isGuessLocked = false,
                isRoleCurrentlyRevealed = false,
                activePrivateReveal = null
            )
        }
        startCountdown(timerSec)
    }

    private fun startCountdown(totalSeconds: Int) {
        stopCountdown()
        countdownJob = viewModelScope.launch {
            var remaining = totalSeconds
            while (remaining > 0 && !_uiState.value.isGuessLocked && _uiState.value.currentScreen == GameScreen.POLICE_GUESS) {
                delay(1000L)
                if (_uiState.value.isGuessLocked || _uiState.value.currentScreen != GameScreen.POLICE_GUESS) {
                    return@launch
                }
                remaining -= 1
                if (remaining in 1..5) {
                    playCue(SoundCue.COUNTDOWN_TICK)
                }
                _uiState.update { it.copy(remainingTimerSeconds = remaining) }
            }
            if (remaining <= 0 && !_uiState.value.isGuessLocked && _uiState.value.currentScreen == GameScreen.POLICE_GUESS) {
                handleCountdownExpired()
            }
        }
    }

    private fun stopCountdown() {
        countdownJob?.cancel()
        countdownJob = null
    }

    fun selectSuspect(playerId: Int) {
        val state = _uiState.value
        if (state.currentScreen != GameScreen.POLICE_GUESS || state.isGuessLocked) return
        playCue(SoundCue.BUTTON_CLICK)
        _uiState.update { it.copy(selectedSuspectPlayerId = playerId) }
    }

    fun confirmPoliceGuess() {
        val state = _uiState.value
        if (state.currentScreen != GameScreen.POLICE_GUESS || state.isGuessLocked) return
        val suspectId = state.selectedSuspectPlayerId ?: return

        stopCountdown()
        finalizePoliceDecision(selectedSuspectId = suspectId, timedOut = false)
    }

    private fun handleCountdownExpired() {
        val state = _uiState.value
        if (state.isGuessLocked) return

        // If Police already highlighted someone before timer hit 0, lock that selection;
        // otherwise if no one was selected, Chor automatically escapes (suspectId = -1).
        val chosenId = state.selectedSuspectPlayerId ?: -1
        finalizePoliceDecision(selectedSuspectId = chosenId, timedOut = true)
    }

    private fun finalizePoliceDecision(selectedSuspectId: Int, timedOut: Boolean) {
        val state = _uiState.value
        val (summary, updatedPlayers) = GameRulesEngine.evaluateRound(
            roundNumber = state.currentRound,
            totalRounds = state.selectedTotalRounds,
            players = state.players,
            roleAssignments = secretRoundAssignments,
            selectedSuspectId = selectedSuspectId,
            timedOut = timedOut
        )

        if (summary.chorCaught) {
            playCue(SoundCue.CORRECT_GUESS)
        } else {
            playCue(SoundCue.WRONG_GUESS)
        }

        _uiState.update {
            it.copy(
                isGuessLocked = true,
                players = updatedPlayers,
                latestRoundSummary = summary,
                roundHistory = it.roundHistory + summary,
                currentScreen = GameScreen.ROUND_RESULT,
                isRoleCurrentlyRevealed = false,
                activePrivateReveal = null
            )
        }
    }

    fun proceedToScoreboard() {
        playCue(SoundCue.BUTTON_CLICK)
        _uiState.update {
            it.copy(
                currentScreen = GameScreen.SCOREBOARD,
                isRoleCurrentlyRevealed = false,
                activePrivateReveal = null
            )
        }
    }

    fun proceedAfterScoreboard() {
        val state = _uiState.value
        if (state.currentRound < state.selectedTotalRounds) {
            playCue(SoundCue.CARD_SHUFFLE)
            beginRoundDistribution(
                roundNumber = state.currentRound + 1,
                currentPlayers = state.players
            )
        } else {
            playCue(SoundCue.VICTORY)
            saveCompletedMatch(state)
            _uiState.update {
                it.copy(
                    currentScreen = GameScreen.FINAL_RESULT,
                    isRoleCurrentlyRevealed = false,
                    activePrivateReveal = null
                )
            }
        }
    }

    private fun saveCompletedMatch(state: ChorifyUiState) {
        val p = state.players
        if (p.size < 4) return
        val sortedByScore = p.sortedByDescending { it.totalScore }
        val champion = sortedByScore.first()
        val totalCatches = state.roundHistory.count { it.chorCaught }
        val totalEscapes = state.roundHistory.count { !it.chorCaught }

        viewModelScope.launch {
            matchHistoryRepository.recordMatch(
                MatchRecordEntity(
                    timestamp = System.currentTimeMillis(),
                    totalRounds = state.selectedTotalRounds,
                    timerSeconds = state.selectedTimerSeconds,
                    championName = champion.name,
                    championScore = champion.totalScore,
                    player1Name = p[0].name,
                    player1Score = p[0].totalScore,
                    player2Name = p[1].name,
                    player2Score = p[1].totalScore,
                    player3Name = p[2].name,
                    player3Score = p[2].totalScore,
                    player4Name = p[3].name,
                    player4Score = p[3].totalScore,
                    totalPoliceCatches = totalCatches,
                    totalChorEscapes = totalEscapes
                )
            )
        }
    }

    fun onAppBackgrounded() {
        // Automatically hide any revealed role and activate privacy shield so recent-tasks never leaks a role
        _uiState.update {
            it.copy(
                isRoleCurrentlyRevealed = false,
                activePrivateReveal = null,
                isPrivacyShieldActive = true
            )
        }
    }

    fun onAppForegrounded() {
        _uiState.update {
            it.copy(isPrivacyShieldActive = false)
        }
    }

    fun setSoundEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setSoundEnabled(enabled) }
    }

    fun setVibrationEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setVibrationEnabled(enabled) }
    }

    fun setAnimationsEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setAnimationsEnabled(enabled) }
    }

    fun setThemeOption(themeOption: AppThemeOption) {
        playCue(SoundCue.BUTTON_CLICK)
        viewModelScope.launch { settingsRepository.setThemeOption(themeOption) }
    }

    fun clearMatchHistory() {
        playCue(SoundCue.BUTTON_CLICK)
        viewModelScope.launch { matchHistoryRepository.clearHistory() }
    }

    class Factory(
        private val matchHistoryRepository: MatchHistoryRepository,
        private val settingsRepository: SettingsRepository,
        private val soundHapticManager: SoundHapticManager?
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ChorifyViewModel(
                matchHistoryRepository = matchHistoryRepository,
                settingsRepository = settingsRepository,
                soundHapticManager = soundHapticManager
            ) as T
        }
    }
}
