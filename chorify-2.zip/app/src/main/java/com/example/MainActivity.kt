package com.example

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.ChorifyDatabase
import com.example.data.MatchHistoryRepository
import com.example.data.SettingsRepository
import com.example.model.GameScreen
import com.example.ui.components.PrivacyShieldOverlay
import com.example.ui.screens.FinalResultScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.HowToPlayScreen
import com.example.ui.screens.MatchHistoryScreen
import com.example.ui.screens.PlayerSetupScreen
import com.example.ui.screens.PoliceGuessScreen
import com.example.ui.screens.PublicRoleDisplayScreen
import com.example.ui.screens.RoundResultScreen
import com.example.ui.screens.ScoreboardScreen
import com.example.ui.screens.SecretRolePassScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.ChorifyTheme
import com.example.util.SoundHapticManager
import com.example.viewmodel.ChorifyViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Prevent recent-tasks switcher and screenshots from leaking Pass & Play secret roles
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        enableEdgeToEdge()

        val database = ChorifyDatabase.getInstance(applicationContext)
        val matchRepository = MatchHistoryRepository(database.matchHistoryDao())
        val settingsRepository = SettingsRepository(applicationContext)
        val soundHapticManager = SoundHapticManager(applicationContext)

        setContent {
            val viewModel: ChorifyViewModel = viewModel(
                factory = ChorifyViewModel.Factory(
                    matchHistoryRepository = matchRepository,
                    settingsRepository = settingsRepository,
                    soundHapticManager = soundHapticManager
                )
            )
            ChorifyApp(viewModel = viewModel)
        }
    }
}

@Composable
fun ChorifyApp(viewModel: ChorifyViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val settings by viewModel.settingsState.collectAsStateWithLifecycle()
    val matchHistory by viewModel.matchHistoryState.collectAsStateWithLifecycle()

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> viewModel.onAppBackgrounded()
                Lifecycle.Event.ON_RESUME -> viewModel.onAppForegrounded()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    ChorifyTheme(themeOption = settings.themeOption) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            contentWindowInsets = WindowInsets.safeDrawing
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Crossfade(
                    targetState = uiState.currentScreen,
                    animationSpec = tween(durationMillis = if (settings.animationsEnabled) 260 else 0),
                    label = "screenTransition"
                ) { screen ->
                    when (screen) {
                        GameScreen.HOME -> {
                            HomeScreen(
                                animationsEnabled = settings.animationsEnabled,
                                onNewGameClick = { viewModel.openPlayerSetup() },
                                onHowToPlayClick = { viewModel.navigateTo(GameScreen.HOW_TO_PLAY) },
                                onMatchHistoryClick = { viewModel.navigateTo(GameScreen.MATCH_HISTORY) },
                                onSettingsClick = { viewModel.navigateTo(GameScreen.SETTINGS) }
                            )
                        }

                        GameScreen.PLAYER_SETUP -> {
                            PlayerSetupScreen(
                                playerNames = uiState.setupPlayerNames,
                                selectedRounds = uiState.selectedTotalRounds,
                                selectedTimerSeconds = uiState.selectedTimerSeconds,
                                animationsEnabled = settings.animationsEnabled,
                                onPlayerNameChange = viewModel::updatePlayerName,
                                onSelectRounds = viewModel::selectTotalRounds,
                                onSelectTimer = viewModel::selectTimerSeconds,
                                onStartMatch = viewModel::startNewMatch,
                                onBackClick = { viewModel.navigateTo(GameScreen.HOME) }
                            )
                        }

                        GameScreen.SECRET_ROLE_PASS -> {
                            val currentPlayer = uiState.players.getOrNull(uiState.currentPassPlayerIndex)
                            if (currentPlayer != null) {
                                SecretRolePassScreen(
                                    roundNumber = uiState.currentRound,
                                    totalRounds = uiState.selectedTotalRounds,
                                    playerIndex = uiState.currentPassPlayerIndex,
                                    currentPlayer = currentPlayer,
                                    isRoleRevealed = uiState.isRoleCurrentlyRevealed,
                                    privateReveal = uiState.activePrivateReveal,
                                    animationsEnabled = settings.animationsEnabled,
                                    onRevealRole = viewModel::revealCurrentPlayerRole,
                                    onHideAndPass = viewModel::hideRoleAndAdvancePlayer,
                                    onAbortToHome = { viewModel.navigateTo(GameScreen.HOME) }
                                )
                            }
                        }

                        GameScreen.PUBLIC_ROLE_DISPLAY -> {
                            val announcement = uiState.publicAnnouncement
                            if (announcement != null) {
                                PublicRoleDisplayScreen(
                                    announcement = announcement,
                                    animationsEnabled = settings.animationsEnabled,
                                    onProceedToPoliceGuess = viewModel::startPoliceGuessPhase,
                                    onAbortToHome = { viewModel.navigateTo(GameScreen.HOME) }
                                )
                            }
                        }

                        GameScreen.POLICE_GUESS -> {
                            val announcement = uiState.publicAnnouncement
                            if (announcement != null) {
                                PoliceGuessScreen(
                                    roundNumber = uiState.currentRound,
                                    totalRounds = uiState.selectedTotalRounds,
                                    players = uiState.players,
                                    announcement = announcement,
                                    remainingSeconds = uiState.remainingTimerSeconds,
                                    totalTimerSeconds = uiState.selectedTimerSeconds,
                                    selectedSuspectId = uiState.selectedSuspectPlayerId,
                                    isGuessLocked = uiState.isGuessLocked,
                                    animationsEnabled = settings.animationsEnabled,
                                    onSelectSuspect = viewModel::selectSuspect,
                                    onConfirmGuess = viewModel::confirmPoliceGuess,
                                    onAbortToHome = { viewModel.navigateTo(GameScreen.HOME) }
                                )
                            }
                        }

                        GameScreen.ROUND_RESULT -> {
                            val summary = uiState.latestRoundSummary
                            if (summary != null) {
                                RoundResultScreen(
                                    summary = summary,
                                    animationsEnabled = settings.animationsEnabled,
                                    onViewScoreboard = viewModel::proceedToScoreboard,
                                    onAbortToHome = { viewModel.navigateTo(GameScreen.HOME) }
                                )
                            }
                        }

                        GameScreen.SCOREBOARD -> {
                            val summary = uiState.latestRoundSummary
                            if (summary != null) {
                                ScoreboardScreen(
                                    summary = summary,
                                    animationsEnabled = settings.animationsEnabled,
                                    onNextAction = viewModel::proceedAfterScoreboard,
                                    onAbortToHome = { viewModel.navigateTo(GameScreen.HOME) }
                                )
                            }
                        }

                        GameScreen.FINAL_RESULT -> {
                            FinalResultScreen(
                                players = uiState.players,
                                roundHistory = uiState.roundHistory,
                                animationsEnabled = settings.animationsEnabled,
                                onPlayAgain = viewModel::playAgainSamePlayers,
                                onNewMatch = viewModel::openPlayerSetup,
                                onHomeClick = { viewModel.navigateTo(GameScreen.HOME) }
                            )
                        }

                        GameScreen.HOW_TO_PLAY -> {
                            HowToPlayScreen(
                                animationsEnabled = settings.animationsEnabled,
                                onBackClick = { viewModel.navigateTo(GameScreen.HOME) }
                            )
                        }

                        GameScreen.MATCH_HISTORY -> {
                            MatchHistoryScreen(
                                matches = matchHistory,
                                animationsEnabled = settings.animationsEnabled,
                                onClearHistory = viewModel::clearMatchHistory,
                                onBackClick = { viewModel.navigateTo(GameScreen.HOME) }
                            )
                        }

                        GameScreen.SETTINGS -> {
                            SettingsScreen(
                                settings = settings,
                                hasHistory = matchHistory.isNotEmpty(),
                                onToggleSound = viewModel::setSoundEnabled,
                                onToggleVibration = viewModel::setVibrationEnabled,
                                onToggleAnimations = viewModel::setAnimationsEnabled,
                                onSelectTheme = viewModel::setThemeOption,
                                onClearHistory = viewModel::clearMatchHistory,
                                onBackClick = { viewModel.navigateTo(GameScreen.HOME) }
                            )
                        }
                    }
                }

                // Privacy Shield overlay when app is paused or in recent tasks
                if (uiState.isPrivacyShieldActive) {
                    PrivacyShieldOverlay()
                }
            }
        }
    }
}
