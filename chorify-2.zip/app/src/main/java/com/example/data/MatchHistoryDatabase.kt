package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "match_history")
data class MatchRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val totalRounds: Int,
    val timerSeconds: Int,
    val championName: String,
    val championScore: Int,
    val player1Name: String,
    val player1Score: Int,
    val player2Name: String,
    val player2Score: Int,
    val player3Name: String,
    val player3Score: Int,
    val player4Name: String,
    val player4Score: Int,
    val totalPoliceCatches: Int,
    val totalChorEscapes: Int
)

@Dao
interface MatchHistoryDao {
    @Query("SELECT * FROM match_history ORDER BY timestamp DESC")
    fun getAllMatches(): Flow<List<MatchRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatch(match: MatchRecordEntity)

    @Query("DELETE FROM match_history")
    suspend fun clearAllMatches()
}

@Database(entities = [MatchRecordEntity::class], version = 1, exportSchema = false)
abstract class ChorifyDatabase : RoomDatabase() {
    abstract fun matchHistoryDao(): MatchHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: ChorifyDatabase? = null

        fun getInstance(context: Context): ChorifyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ChorifyDatabase::class.java,
                    "chorify2_offline.db"
                ).fallbackToDestructiveMigration(true).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class MatchHistoryRepository(private val dao: MatchHistoryDao) {
    val allMatches: Flow<List<MatchRecordEntity>> = dao.getAllMatches()

    suspend fun recordMatch(match: MatchRecordEntity) {
        dao.insertMatch(match)
    }

    suspend fun clearHistory() {
        dao.clearAllMatches()
    }
}
