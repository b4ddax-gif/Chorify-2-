package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class SoundCue {
    BUTTON_CLICK,
    CARD_SHUFFLE,
    ROLE_REVEAL,
    ROLE_HIDE,
    COUNTDOWN_TICK,
    GUESS_CONFIRM,
    CORRECT_GUESS,
    WRONG_GUESS,
    CHOR_REVEAL,
    VICTORY
}

/**
 * Purely offline procedural PCM synthesizer and haptic feedback controller.
 * Generates clean, atmospheric musical chimes and tactile feedback without external assets.
 */
class SoundHapticManager(context: Context) {

    private val appContext = context.applicationContext
    private val audioScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val vibrator: Vibrator? by lazy {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        }.getOrNull()
    }

    fun triggerCue(
        cue: SoundCue,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean
    ) {
        if (vibrationEnabled) {
            triggerHaptic(cue)
        }
        if (soundEnabled) {
            audioScope.launch {
                runCatching { playSynthesizedCue(cue) }
            }
        }
    }

    private fun triggerHaptic(cue: SoundCue) {
        runCatching {
            val vib = vibrator ?: return
            if (!vib.hasVibrator()) return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = when (cue) {
                    SoundCue.BUTTON_CLICK, SoundCue.COUNTDOWN_TICK ->
                        VibrationEffect.createOneShot(18L, 80)
                    SoundCue.CARD_SHUFFLE ->
                        VibrationEffect.createWaveform(longArrayOf(0, 20, 40, 20, 40, 25), -1)
                    SoundCue.ROLE_REVEAL, SoundCue.ROLE_HIDE ->
                        VibrationEffect.createOneShot(35L, 140)
                    SoundCue.GUESS_CONFIRM, SoundCue.CHOR_REVEAL ->
                        VibrationEffect.createWaveform(longArrayOf(0, 45, 60, 75), -1)
                    SoundCue.CORRECT_GUESS, SoundCue.VICTORY ->
                        VibrationEffect.createWaveform(longArrayOf(0, 50, 50, 60, 50, 120), -1)
                    SoundCue.WRONG_GUESS ->
                        VibrationEffect.createWaveform(longArrayOf(0, 110, 70, 140), -1)
                }
                vib.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(30L)
            }
        }
    }

    private fun playSynthesizedCue(cue: SoundCue) {
        val notes: List<Pair<Double, Int>> = when (cue) {
            SoundCue.BUTTON_CLICK -> listOf(587.33 to 45)
            SoundCue.ROLE_HIDE -> listOf(440.0 to 50, 329.63 to 60)
            SoundCue.CARD_SHUFFLE -> listOf(330.0 to 40, 392.0 to 40, 493.88 to 45, 587.33 to 60)
            SoundCue.ROLE_REVEAL -> listOf(440.0 to 70, 554.37 to 70, 659.25 to 130)
            SoundCue.COUNTDOWN_TICK -> listOf(880.0 to 35)
            SoundCue.GUESS_CONFIRM -> listOf(523.25 to 80, 659.25 to 120)
            SoundCue.CHOR_REVEAL -> listOf(293.66 to 90, 349.23 to 90, 440.0 to 160)
            SoundCue.CORRECT_GUESS -> listOf(523.25 to 90, 659.25 to 90, 783.99 to 110, 1046.50 to 220)
            SoundCue.WRONG_GUESS -> listOf(392.0 to 130, 369.99 to 130, 329.63 to 240)
            SoundCue.VICTORY -> listOf(
                523.25 to 90,
                659.25 to 90,
                783.99 to 90,
                1046.50 to 150,
                783.99 to 80,
                1046.50 to 280
            )
        }
        playNotesSequence(notes)
    }

    private fun playNotesSequence(notes: List<Pair<Double, Int>>) {
        val sampleRate = 22050
        val totalDurationMs = notes.sumOf { it.second }
        val totalSamples = (sampleRate * (totalDurationMs / 1000.0)).toInt().coerceAtLeast(1)
        val buffer = ShortArray(totalSamples)

        var currentSampleIndex = 0
        for ((freq, durationMs) in notes) {
            val noteSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            for (i in 0 until noteSamples) {
                if (currentSampleIndex >= totalSamples) break
                val t = i.toDouble() / sampleRate
                val envelope = exp(-4.5 * (i.toDouble() / noteSamples))
                val wave = sin(2.0 * PI * freq * t) + 0.25 * sin(4.0 * PI * freq * t)
                val sampleValue = (wave * envelope * 0.35 * Short.MAX_VALUE).toInt()
                    .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                buffer[currentSampleIndex++] = sampleValue.toShort()
            }
        }

        val audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(buffer.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        audioTrack.write(buffer, 0, buffer.size)
        audioTrack.play()
        Thread.sleep(totalDurationMs.toLong() + 40L)
        audioTrack.stop()
        audioTrack.release()
    }
}
