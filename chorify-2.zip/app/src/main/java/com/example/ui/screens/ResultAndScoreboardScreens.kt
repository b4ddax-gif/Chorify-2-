package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.LocalPolice
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Player
import com.example.model.RoundSummary
import com.example.ui.components.CinematicBackground
import com.example.ui.components.GlassSecondaryButton
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.TopGameBar
import com.example.ui.components.visualStyle
import com.example.ui.theme.ChorRed
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MantriSilver
import com.example.ui.theme.PoliceBlue
import com.example.ui.theme.RajaGold
import com.example.ui.theme.SuccessEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun RoundResultScreen(
    summary: RoundSummary,
    animationsEnabled: Boolean,
    onViewScoreboard: () -> Unit,
    onAbortToHome: () -> Unit
) {
    var showExitConfirm by remember { mutableStateOf(false) }
    BackHandler { showExitConfirm = true }

    if (showExitConfirm) {
        AbortMatchDialog(
            onConfirmAbort = {
                showExitConfirm = false
                onAbortToHome()
            },
            onDismiss = { showExitConfirm = false }
        )
    }

    val bannerColor = if (summary.chorCaught) SuccessEmerald else ChorRed
    val headlineText = if (summary.chorCaught) {
        stringResource(R.string.result_chor_caught)
    } else {
        stringResource(R.string.result_chor_escaped)
    }

    CinematicBackground(
        animationsEnabled = animationsEnabled,
        accentColor = bannerColor,
        secondaryAccent = RajaGold
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopGameBar(
                title = "ROYAL VERDICT",
                subtitle = "ROUND ${summary.roundNumber} OF ${summary.totalRounds}",
                onBackClick = { showExitConfirm = true }
            )

            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Dramatic Verdict Banner Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(2.dp, bannerColor, RoundedCornerShape(24.dp))
                        .testTag("round_result_banner"),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = bannerColor.copy(alpha = 0.15f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(76.dp)
                                .clip(CircleShape)
                                .background(bannerColor.copy(alpha = 0.22f))
                                .border(2.dp, bannerColor, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (summary.chorCaught) Icons.Default.Shield else Icons.Default.Warning,
                                contentDescription = headlineText,
                                tint = bannerColor,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = headlineText,
                            style = MaterialTheme.typography.displayMedium,
                            color = bannerColor,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.testTag("round_verdict_title")
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        val detailNarrative = when {
                            summary.timedOut && !summary.chorCaught ->
                                "Time expired! Police (${summary.policePlayerName}) failed to lock onto the Chor."
                            summary.chorCaught ->
                                "Police (${summary.policePlayerName}) apprehended ${summary.actualChorName} red-handed!"
                            else ->
                                "Police (${summary.policePlayerName}) accused ${summary.selectedSuspectName}, allowing the real Chor to slip into the night!"
                        }

                        Text(
                            text = detailNarrative,
                            style = MaterialTheme.typography.bodyLarge,
                            color = TextPrimary,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // True Chor & Mantri Reveal Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp)),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                    )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "SECRET IDENTITIES UNMASKED",
                            style = MaterialTheme.typography.labelLarge,
                            color = RajaGold
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            UnmaskedRoleBox(
                                emoji = "🥷",
                                label = "ACTUAL CHOR",
                                playerName = summary.actualChorName,
                                color = ChorRed,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("actual_chor_reveal")
                            )
                            UnmaskedRoleBox(
                                emoji = "🧠",
                                label = "ACTUAL MANTRI",
                                playerName = summary.actualMantriName,
                                color = MantriSilver,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("actual_mantri_reveal")
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Round Points Breakdown
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp)),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                    )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "ROUND POINTS AWARDED",
                            style = MaterialTheme.typography.labelLarge,
                            color = PoliceBlue
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        summary.playerResults.forEach { res ->
                            val roleStyle = res.role.visualStyle()
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = res.role.emoji, fontSize = 22.sp)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = res.playerName,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = TextPrimary
                                        )
                                        Text(
                                            text = res.role.displayName,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = roleStyle.primaryColor
                                        )
                                    }
                                }

                                Text(
                                    text = "+${res.roundPoints}",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontFamily = JetBrainsMonoFontFamily
                                    ),
                                    color = if (res.roundPoints > 0) SuccessEmerald else TextSecondary,
                                    modifier = Modifier.testTag("round_points_${res.role.name}")
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                GoldPrimaryButton(
                    text = stringResource(R.string.btn_view_scoreboard),
                    onClick = onViewScoreboard,
                    icon = Icons.Default.Leaderboard,
                    testTag = "btn_view_scoreboard"
                )

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun UnmaskedRoleBox(
    emoji: String,
    label: String,
    playerName: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(color.copy(alpha = 0.14f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = emoji, fontSize = 28.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = color
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = playerName,
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun ScoreboardScreen(
    summary: RoundSummary,
    animationsEnabled: Boolean,
    onNextAction: () -> Unit,
    onAbortToHome: () -> Unit
) {
    var showExitConfirm by remember { mutableStateOf(false) }
    BackHandler { showExitConfirm = true }

    if (showExitConfirm) {
        AbortMatchDialog(
            onConfirmAbort = {
                showExitConfirm = false
                onAbortToHome()
            },
            onDismiss = { showExitConfirm = false }
        )
    }

    var startScoreCount by remember { mutableStateOf(!animationsEnabled) }
    LaunchedEffect(Unit) {
        startScoreCount = true
    }

    val isFinalRound = summary.roundNumber >= summary.totalRounds
    val actionLabel = if (isFinalRound) {
        stringResource(R.string.btn_final_results)
    } else {
        stringResource(R.string.btn_next_round)
    }

    CinematicBackground(animationsEnabled = animationsEnabled) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopGameBar(
                title = stringResource(R.string.scoreboard_title),
                subtitle = "AFTER ROUND ${summary.roundNumber} OF ${summary.totalRounds}",
                onBackClick = { showExitConfirm = true }
            )

            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, RajaGold.copy(alpha = 0.6f), RoundedCornerShape(22.dp))
                        .testTag("scoreboard_table_card"),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
                    )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        // Table Header: PLAYER NAME | ROLE | ROUND POINTS | TOTAL POINTS
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PLAYER",
                                style = MaterialTheme.typography.labelMedium,
                                color = RajaGold,
                                modifier = Modifier.weight(1.35f)
                            )
                            Text(
                                text = "ROLE",
                                style = MaterialTheme.typography.labelMedium,
                                color = RajaGold,
                                modifier = Modifier.weight(1.05f)
                            )
                            Text(
                                text = "ROUND",
                                style = MaterialTheme.typography.labelMedium,
                                color = RajaGold,
                                textAlign = TextAlign.End,
                                modifier = Modifier.weight(0.8f)
                            )
                            Text(
                                text = "TOTAL",
                                style = MaterialTheme.typography.labelMedium,
                                color = RajaGold,
                                textAlign = TextAlign.End,
                                modifier = Modifier.weight(0.95f)
                            )
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)

                        summary.playerResults.forEachIndexed { idx, row ->
                            val roleStyle = row.role.visualStyle()
                            val animatedRoundPts by animateIntAsState(
                                targetValue = if (startScoreCount) row.roundPoints else 0,
                                animationSpec = tween(
                                    durationMillis = if (animationsEnabled) 750 else 0,
                                    easing = FastOutSlowInEasing
                                ),
                                label = "roundPts_$idx"
                            )
                            val animatedTotalPts by animateIntAsState(
                                targetValue = if (startScoreCount) row.totalPointsAfterRound else (row.totalPointsAfterRound - row.roundPoints),
                                animationSpec = tween(
                                    durationMillis = if (animationsEnabled) 900 else 0,
                                    easing = FastOutSlowInEasing
                                ),
                                label = "totalPts_$idx"
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1.35f)) {
                                    Text(
                                        text = "${idx + 1}. ${row.playerName}",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = TextPrimary
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1.05f)
                                ) {
                                    Text(text = row.role.emoji, fontSize = 15.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = row.role.displayName,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = roleStyle.primaryColor
                                    )
                                }

                                Text(
                                    text = "+$animatedRoundPts",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (row.roundPoints > 0) SuccessEmerald else TextSecondary,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.weight(0.8f)
                                )

                                Text(
                                    text = "$animatedTotalPts",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontWeight = FontWeight.ExtraBold
                                    ),
                                    color = RajaGold,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier
                                        .weight(0.95f)
                                        .testTag("total_score_player_${row.playerId}")
                                )
                            }

                            if (idx < summary.playerResults.lastIndex) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                GoldPrimaryButton(
                    text = actionLabel,
                    onClick = onNextAction,
                    icon = if (isFinalRound) Icons.Default.EmojiEvents else Icons.Default.PlayArrow,
                    testTag = "btn_next_round_or_final"
                )
            }
        }
    }
}

@Composable
fun FinalResultScreen(
    players: List<Player>,
    roundHistory: List<RoundSummary>,
    animationsEnabled: Boolean,
    onPlayAgain: () -> Unit,
    onNewMatch: () -> Unit,
    onHomeClick: () -> Unit
) {
    BackHandler(onBack = onHomeClick)

    val rankedPlayers = remember(players) {
        players.sortedByDescending { it.totalScore }
    }
    val topScore = rankedPlayers.firstOrNull()?.totalScore ?: 0
    val champions = rankedPlayers.filter { it.totalScore == topScore }
    val championTitleName = champions.joinToString(" & ") { it.name }

    val totalPoliceCatches = roundHistory.count { it.chorCaught }
    val totalChorEscapes = roundHistory.count { !it.chorCaught }

    CinematicBackground(
        animationsEnabled = animationsEnabled,
        accentColor = RajaGold,
        secondaryAccent = SuccessEmerald
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopGameBar(
                title = stringResource(R.string.final_champion_title),
                subtitle = "${roundHistory.size} ROUNDS COMPLETED",
                onBackClick = onHomeClick
            )

            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Grand Champion Crown Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            2.dp,
                            Brush.linearGradient(listOf(RajaGold, SuccessEmerald)),
                            RoundedCornerShape(26.dp)
                        )
                        .testTag("champion_banner_card"),
                    shape = RoundedCornerShape(26.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(88.dp)
                                .clip(CircleShape)
                                .background(RajaGold.copy(alpha = 0.2f))
                                .border(2.dp, RajaGold, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "👑", fontSize = 44.sp)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "CHORIFY CHAMPION",
                            style = MaterialTheme.typography.labelLarge,
                            color = RajaGold
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = championTitleName.uppercase(),
                            style = MaterialTheme.typography.displayMedium,
                            color = TextPrimary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.testTag("champion_name_text")
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "$topScore TOTAL POINTS",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontFamily = JetBrainsMonoFontFamily
                            ),
                            color = SuccessEmerald
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Match Telemetry Summary (Police Catches vs Chor Escapes)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatSummaryCard(
                        icon = Icons.Default.LocalPolice,
                        value = "$totalPoliceCatches",
                        label = "POLICE CATCHES",
                        color = PoliceBlue,
                        modifier = Modifier.weight(1f)
                    )
                    StatSummaryCard(
                        icon = Icons.Default.EmojiEvents,
                        value = "$totalChorEscapes",
                        label = "CHOR ESCAPES",
                        color = ChorRed,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Final Ranking Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp)),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                    )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "FINAL STANDINGS & STATS",
                            style = MaterialTheme.typography.labelLarge,
                            color = RajaGold
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        rankedPlayers.forEachIndexed { idx, player ->
                            val medal = when (idx) {
                                0 -> "🥇"
                                1 -> "🥈"
                                2 -> "🥉"
                                else -> "4th"
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = medal,
                                        fontSize = 22.sp,
                                        modifier = Modifier.width(36.dp)
                                    )
                                    Column {
                                        Text(
                                            text = player.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = TextPrimary
                                        )
                                        Text(
                                            text = "Rounds Won: ${player.roundsWon} • Catches: ${player.policeSuccessCount} • Escapes: ${player.chorEscapeCount}",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                                            color = TextSecondary
                                        )
                                    }
                                }

                                Text(
                                    text = "${player.totalScore} pts",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = if (idx == 0) RajaGold else TextPrimary
                                )
                            }
                            if (idx < rankedPlayers.lastIndex) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))

                GoldPrimaryButton(
                    text = stringResource(R.string.btn_play_again),
                    onClick = onPlayAgain,
                    icon = Icons.Default.Refresh,
                    testTag = "btn_play_again"
                )

                Spacer(modifier = Modifier.height(10.dp))

                GlassSecondaryButton(
                    text = stringResource(R.string.btn_new_match),
                    onClick = onNewMatch,
                    icon = Icons.Default.PlayArrow,
                    testTag = "btn_new_match"
                )

                Spacer(modifier = Modifier.height(10.dp))

                GlassSecondaryButton(
                    text = stringResource(R.string.btn_home),
                    onClick = onHomeClick,
                    icon = Icons.Default.Home,
                    testTag = "btn_home"
                )

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun StatSummaryCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: String,
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(18.dp)),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(26.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.displaySmall.copy(
                    fontFamily = JetBrainsMonoFontFamily
                ),
                color = TextPrimary
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = color,
                textAlign = TextAlign.Center
            )
        }
    }
}
