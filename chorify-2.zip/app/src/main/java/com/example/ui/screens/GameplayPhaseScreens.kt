package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.LocalPolice
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Player
import com.example.model.Role
import com.example.ui.components.CinematicBackground
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.RoleIdentityCard
import com.example.ui.components.TopGameBar
import com.example.ui.theme.ChorRed
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.PoliceBlue
import com.example.ui.theme.PoliceBlueSurface
import com.example.ui.theme.RajaGold
import com.example.ui.theme.RajaGoldSurface
import com.example.ui.theme.SuccessEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.PassAndPlayPrivateView
import com.example.viewmodel.PublicCourtAnnouncement

@Composable
fun SecretRolePassScreen(
    roundNumber: Int,
    totalRounds: Int,
    playerIndex: Int,
    currentPlayer: Player,
    isRoleRevealed: Boolean,
    privateReveal: PassAndPlayPrivateView?,
    animationsEnabled: Boolean,
    onRevealRole: () -> Unit,
    onHideAndPass: () -> Unit,
    onAbortToHome: () -> Unit
) {
    var showExitConfirm by remember { mutableStateOf(false) }

    // Prevent accidental back navigation from revealing previous player's role!
    BackHandler {
        showExitConfirm = true
    }

    if (showExitConfirm) {
        AbortMatchDialog(
            onConfirmAbort = {
                showExitConfirm = false
                onAbortToHome()
            },
            onDismiss = { showExitConfirm = false }
        )
    }

    val rotation by animateFloatAsState(
        targetValue = if (isRoleRevealed) 180f else 0f,
        animationSpec = tween(
            durationMillis = if (animationsEnabled) 420 else 0,
            easing = FastOutSlowInEasing
        ),
        label = "cardFlip"
    )

    CinematicBackground(animationsEnabled = animationsEnabled) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopGameBar(
                title = "SECRET DECREE",
                subtitle = "PASS & PLAY • PLAYER ${playerIndex + 1} OF 4",
                onBackClick = { showExitConfirm = true },
                trailingBadge = "ROUND $roundNumber/$totalRounds"
            )

            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Step progress dots for the 4 players
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(bottom = 20.dp)
                ) {
                    for (i in 0..3) {
                        val isDone = i < playerIndex
                        val isCurrent = i == playerIndex
                        val dotColor = when {
                            isCurrent -> RajaGold
                            isDone -> SuccessEmerald
                            else -> MaterialTheme.colorScheme.outline
                        }
                        Box(
                            modifier = Modifier
                                .height(8.dp)
                                .width(if (isCurrent) 36.dp else 18.dp)
                                .clip(RoundedCornerShape(50))
                                .background(dotColor)
                        )
                    }
                }

                // Main Flip Vault Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .graphicsLayer {
                            rotationY = rotation
                            cameraDistance = 14f * density
                        }
                ) {
                    if (rotation <= 90f) {
                        // Front: Sealed Pass Screen
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    2.dp,
                                    Brush.linearGradient(listOf(RajaGold, PoliceBlue)),
                                    RoundedCornerShape(24.dp)
                                )
                                .testTag("pass_phone_card"),
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(84.dp)
                                        .clip(CircleShape)
                                        .background(RajaGold.copy(alpha = 0.15f))
                                        .border(2.dp, RajaGold, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Sealed Role",
                                        tint = RajaGold,
                                        modifier = Modifier.size(40.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                Text(
                                    text = stringResource(R.string.pass_phone_prefix),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = TextSecondary
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = currentPlayer.name.uppercase(),
                                    style = MaterialTheme.typography.displayMedium,
                                    color = RajaGold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.testTag("pass_target_player_name")
                                )

                                Text(
                                    text = currentPlayer.cornerLabel,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = PoliceBlue,
                                    modifier = Modifier.padding(top = 4.dp)
                                )

                                Spacer(modifier = Modifier.height(20.dp))

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color.Black.copy(alpha = 0.3f))
                                        .padding(14.dp)
                                ) {
                                    Text(
                                        text = stringResource(R.string.pass_phone_warning),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    } else {
                        // Back: Private Revealed Role (counter-rotated 180deg so text is upright)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .graphicsLayer { rotationY = 180f }
                                .testTag("revealed_role_card")
                        ) {
                            if (privateReveal != null) {
                                RoleIdentityCard(
                                    role = privateReveal.role,
                                    playerName = privateReveal.playerName,
                                    cornerLabel = privateReveal.cornerLabel
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                AnimatedContent(
                    targetState = isRoleRevealed,
                    transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(150)) },
                    label = "passActionButtons"
                ) { revealed ->
                    if (!revealed) {
                        GoldPrimaryButton(
                            text = stringResource(R.string.btn_reveal_role),
                            onClick = onRevealRole,
                            icon = Icons.Default.Visibility,
                            testTag = "btn_reveal_role"
                        )
                    } else {
                        GoldPrimaryButton(
                            text = stringResource(R.string.btn_hide_and_pass),
                            onClick = onHideAndPass,
                            icon = Icons.Default.VisibilityOff,
                            accentColor = PoliceBlue,
                            testTag = "btn_hide_and_pass"
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PublicRoleDisplayScreen(
    announcement: PublicCourtAnnouncement,
    animationsEnabled: Boolean,
    onProceedToPoliceGuess: () -> Unit,
    onAbortToHome: () -> Unit
) {
    var showExitConfirm by remember { mutableStateOf(false) }

    BackHandler {
        showExitConfirm = true
    }

    if (showExitConfirm) {
        AbortMatchDialog(
            onConfirmAbort = {
                showExitConfirm = false
                onAbortToHome()
            },
            onDismiss = { showExitConfirm = false }
        )
    }

    CinematicBackground(animationsEnabled = animationsEnabled) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopGameBar(
                title = stringResource(R.string.public_roles_title),
                subtitle = "PUBLIC IDENTITIES ANNOUNCED",
                onBackClick = { showExitConfirm = true },
                trailingBadge = "ROUND ${announcement.roundNumber}/${announcement.totalRounds}"
            )

            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Public RAJA Card
                PublicRoleAnnouncementCard(
                    roleTitle = "RAJA",
                    emoji = "👑",
                    playerName = announcement.rajaPlayer.name,
                    cornerLabel = announcement.rajaPlayer.cornerLabel,
                    accentColor = RajaGold,
                    surfaceColor = RajaGoldSurface,
                    subtitle = "Receives +1000 Royal Points",
                    testTag = "public_raja_card"
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Public POLICE Card
                PublicRoleAnnouncementCard(
                    roleTitle = "POLICE",
                    emoji = "🕵️",
                    playerName = announcement.policePlayer.name,
                    cornerLabel = announcement.policePlayer.cornerLabel,
                    accentColor = PoliceBlue,
                    surfaceColor = PoliceBlueSurface,
                    subtitle = "Must identify the hidden Chor (+500 pts)",
                    testTag = "public_police_card"
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Hidden Roles Notice Card (Strictly does NOT reveal Mantri or Chor)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
                        .testTag("hidden_roles_notice_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.VisibilityOff,
                            contentDescription = "Hidden Roles",
                            tint = ChorRed,
                            modifier = Modifier.size(34.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = stringResource(R.string.two_roles_hidden),
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.testTag("two_roles_hidden_text")
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "The remaining two players sit in silence as secret suspects. Neither their icons nor their roles are shown.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                GoldPrimaryButton(
                    text = stringResource(R.string.btn_proceed_to_guess),
                    onClick = onProceedToPoliceGuess,
                    icon = Icons.Default.LocalPolice,
                    testTag = "btn_proceed_to_guess"
                )
            }
        }
    }
}

@Composable
private fun PublicRoleAnnouncementCard(
    roleTitle: String,
    emoji: String,
    playerName: String,
    cornerLabel: String,
    accentColor: Color,
    surfaceColor: Color,
    subtitle: String,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.5.dp, accentColor, RoundedCornerShape(20.dp))
            .testTag(testTag),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = surfaceColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.2f))
                    .border(2.dp, accentColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(text = emoji, fontSize = 30.sp)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "$roleTitle: $playerName",
                    style = MaterialTheme.typography.headlineMedium,
                    color = accentColor
                )
                Text(
                    text = cornerLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary,
                    modifier = Modifier.padding(top = 2.dp)
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
fun PoliceGuessScreen(
    roundNumber: Int,
    totalRounds: Int,
    players: List<Player>,
    announcement: PublicCourtAnnouncement,
    remainingSeconds: Int,
    totalTimerSeconds: Int,
    selectedSuspectId: Int?,
    isGuessLocked: Boolean,
    animationsEnabled: Boolean,
    onSelectSuspect: (Int) -> Unit,
    onConfirmGuess: () -> Unit,
    onAbortToHome: () -> Unit
) {
    var showExitConfirm by remember { mutableStateOf(false) }

    BackHandler {
        showExitConfirm = true
    }

    if (showExitConfirm) {
        AbortMatchDialog(
            onConfirmAbort = {
                showExitConfirm = false
                onAbortToHome()
            },
            onDismiss = { showExitConfirm = false }
        )
    }

    val isUrgent = remainingSeconds <= 5
    val timerColor = if (isUrgent) ChorRed else PoliceBlue
    val progress = (remainingSeconds.toFloat() / totalTimerSeconds.coerceAtLeast(1)).coerceIn(0f, 1f)

    CinematicBackground(
        animationsEnabled = animationsEnabled,
        accentColor = PoliceBlue,
        secondaryAccent = ChorRed
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopGameBar(
                title = "INVESTIGATION",
                subtitle = "POLICE: ${announcement.policePlayer.name.uppercase()}",
                onBackClick = { showExitConfirm = true },
                trailingBadge = "ROUND $roundNumber/$totalRounds"
            )

            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Countdown Dial & Prompt Header
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, timerColor.copy(alpha = 0.7f), RoundedCornerShape(22.dp)),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.size(68.dp)
                        ) {
                            CircularProgressIndicator(
                                progress = { progress },
                                modifier = Modifier.fillMaxSize(),
                                color = timerColor,
                                strokeWidth = 6.dp,
                                trackColor = Color.Black.copy(alpha = 0.35f)
                            )
                            Text(
                                text = "${remainingSeconds}s",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.ExtraBold
                                ),
                                color = timerColor,
                                modifier = Modifier.testTag("countdown_timer_text")
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.police_guess_header),
                                style = MaterialTheme.typography.headlineLarge,
                                color = TextPrimary,
                                modifier = Modifier.testTag("police_guess_header")
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${announcement.policePlayer.name}, select one player below and lock your verdict.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // All 4 Players Shown as Selectable Cards
                // Note: Only Raja and Police have public badges; the other two players have NO role badge at all!
                players.forEach { player ->
                    val isSelected = selectedSuspectId == player.id
                    val publicBadgeText: String? = when (player.id) {
                        announcement.rajaPlayer.id -> "👑 PUBLIC RAJA"
                        announcement.policePlayer.id -> "🕵️ PUBLIC POLICE"
                        else -> null // Strictly hidden! Neither Mantri nor Chor is indicated
                    }
                    val publicBadgeColor: Color = when (player.id) {
                        announcement.rajaPlayer.id -> RajaGold
                        announcement.policePlayer.id -> PoliceBlue
                        else -> TextMuted
                    }

                    val borderColor = if (isSelected) ChorRed else MaterialTheme.colorScheme.outline
                    val cardBg = if (isSelected) {
                        ChorRed.copy(alpha = 0.18f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f)
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .border(if (isSelected) 2.dp else 1.dp, borderColor, RoundedCornerShape(18.dp))
                            .clickable(enabled = !isGuessLocked) {
                                onSelectSuspect(player.id)
                            }
                            .testTag("suspect_card_${player.id}"),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = cardBg)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 18.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isSelected) ChorRed else Color.Black.copy(alpha = 0.35f)
                                        )
                                        .border(
                                            1.5.dp,
                                            if (isSelected) ChorRed else MaterialTheme.colorScheme.outline,
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${player.id + 1}",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontFamily = JetBrainsMonoFontFamily
                                        ),
                                        color = if (isSelected) Color.White else TextPrimary
                                    )
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                Column {
                                    Text(
                                        text = player.name,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = TextPrimary
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(top = 2.dp)
                                    ) {
                                        Text(
                                            text = player.cornerLabel,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = TextSecondary
                                        )
                                        if (publicBadgeText != null) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "• $publicBadgeText",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = publicBadgeColor
                                            )
                                        }
                                    }
                                }
                            }

                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Selected Suspect",
                                    tint = ChorRed,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                GoldPrimaryButton(
                    text = stringResource(R.string.btn_confirm_guess),
                    onClick = onConfirmGuess,
                    enabled = selectedSuspectId != null && !isGuessLocked,
                    icon = Icons.Default.Gavel,
                    accentColor = ChorRed,
                    contentColor = Color.White,
                    testTag = "btn_confirm_guess"
                )

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
fun AbortMatchDialog(
    onConfirmAbort: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = {
            Text(
                text = "END CURRENT MATCH?",
                style = MaterialTheme.typography.headlineLarge
            )
        },
        text = {
            Text(
                text = "Returning to the Home screen will end the current match and clear all secret roles.",
                style = MaterialTheme.typography.bodyMedium
            )
        },
        confirmButton = {
            TextButton(onClick = onConfirmAbort) {
                Text("EXIT TO HOME", color = ChorRed, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CONTINUE PLAYING", color = RajaGold, fontWeight = FontWeight.Bold)
            }
        }
    )
}
