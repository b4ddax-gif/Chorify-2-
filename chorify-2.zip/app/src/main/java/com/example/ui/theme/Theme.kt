package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import com.example.model.AppThemeOption

private val MidnightScheme = darkColorScheme(
    primary = RajaGold,
    onPrimary = MidnightBg,
    primaryContainer = MidnightCardElevated,
    onPrimaryContainer = TextPrimary,
    secondary = PoliceBlue,
    onSecondary = MidnightBg,
    secondaryContainer = PoliceBlueSurface,
    onSecondaryContainer = PoliceBlue,
    tertiary = ChorRed,
    onTertiary = MidnightBg,
    tertiaryContainer = ChorRedSurface,
    onTertiaryContainer = ChorRed,
    background = MidnightBg,
    onBackground = TextPrimary,
    surface = MidnightSurface,
    onSurface = TextPrimary,
    surfaceVariant = MidnightCard,
    onSurfaceVariant = TextSecondary,
    outline = MidnightBorder,
    error = DangerCrimson
)

private val CrimsonScheme = darkColorScheme(
    primary = RajaGold,
    onPrimary = CrimsonBg,
    primaryContainer = CrimsonCardElevated,
    onPrimaryContainer = TextPrimary,
    secondary = PoliceBlue,
    onSecondary = CrimsonBg,
    secondaryContainer = PoliceBlueSurface,
    onSecondaryContainer = PoliceBlue,
    tertiary = ChorRed,
    onTertiary = CrimsonBg,
    tertiaryContainer = ChorRedSurface,
    onTertiaryContainer = ChorRed,
    background = CrimsonBg,
    onBackground = TextPrimary,
    surface = CrimsonSurface,
    onSurface = TextPrimary,
    surfaceVariant = CrimsonCard,
    onSurfaceVariant = TextSecondary,
    outline = CrimsonBorder,
    error = DangerCrimson
)

private val EmeraldScheme = darkColorScheme(
    primary = RajaGold,
    onPrimary = EmeraldBg,
    primaryContainer = EmeraldCardElevated,
    onPrimaryContainer = TextPrimary,
    secondary = PoliceBlue,
    onSecondary = EmeraldBg,
    secondaryContainer = PoliceBlueSurface,
    onSecondaryContainer = PoliceBlue,
    tertiary = ChorRed,
    onTertiary = EmeraldBg,
    tertiaryContainer = ChorRedSurface,
    onTertiaryContainer = ChorRed,
    background = EmeraldBg,
    onBackground = TextPrimary,
    surface = EmeraldSurface,
    onSurface = TextPrimary,
    surfaceVariant = EmeraldCard,
    onSurfaceVariant = TextSecondary,
    outline = EmeraldBorder,
    error = DangerCrimson
)

@Composable
fun ChorifyTheme(
    themeOption: AppThemeOption = AppThemeOption.MIDNIGHT_OBSIDIAN,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeOption) {
        AppThemeOption.MIDNIGHT_OBSIDIAN -> MidnightScheme
        AppThemeOption.ROYAL_CRIMSON -> CrimsonScheme
        AppThemeOption.IMPERIAL_EMERALD -> EmeraldScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
