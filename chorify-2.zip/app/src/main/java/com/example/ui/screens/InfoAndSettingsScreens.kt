package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.MatchRecordEntity
import com.example.model.AppThemeOption
import com.example.model.GameSettings
import com.example.model.Role
import com.example.ui.components.CinematicBackground
import com.example.ui.components.GlassSecondaryButton
import com.example.ui.components.TopGameBar
import com.example.ui.components.visualStyle
import com.example.ui.theme.ChorRed
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.PoliceBlue
import com.example.ui.theme.RajaGold
import com.example.ui.theme.SuccessEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HowToPlayScreen(
    animationsEnabled: Boolean,
    onBackClick: () -> Unit
) {
    BackHandler(onBack = onBackClick)

    val rulesList = listOf(
        "Four players sit at four corners around the device." to "Each round deals four unique roles with zero duplicates.",
        "Four distinct roles govern the royal court." to "👑 Raja, 🕵️ Police, 🧠 Mantri, and 🥷 Chor.",
        "Raja and Police are publicly visible to everyone." to "After Pass & Play, the court publicly announces who holds the Crown and the Badge.",
        "Mantri and Chor remain strictly hidden." to "Neither Mantri nor Chor has any public indicator before the verdict.",
        "Police must identify the Chor before the timer expires." to "The Police observes expressions, interrogates suspects, and locks in one final guess.",
        "Correct Guess: Police +500 | Chor +0." to "When the Police catches the Chor, justice prevails in the palace.",
        "Wrong Guess: Chor +500 | Police +0." to "If the Police accuses an innocent player or runs out of time, the Chor escapes with the loot!",
        "Raja always receives +1000 points." to "Royal privilege guarantees +1000 points every round.",
        "Mantri always receives +300 points." to "The royal advisor earns a steady +300 points every round.",
        "Highest cumulative score across all rounds wins." to "At the end of 3, 5, or 10 rounds, the highest scorer is crowned CHORIFY CHAMPION!"
    )

    CinematicBackground(animationsEnabled = animationsEnabled) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopGameBar(
                title = stringResource(R.string.btn_how_to_play),
                subtitle = "OFFICIAL ROYAL CODEX",
                onBackClick = onBackClick
            )

            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                // Role Identity Cards Overview
                Text(
                    text = "THE FOUR ROLES",
                    style = MaterialTheme.typography.labelLarge,
                    color = RajaGold,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                Role.entries.forEach { role ->
                    val style = role.visualStyle()
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .border(1.dp, style.primaryColor.copy(alpha = 0.55f), RoundedCornerShape(18.dp)),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = style.surfaceColor)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = role.emoji, fontSize = 30.sp)
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = role.displayName,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = style.primaryColor
                                    )
                                    Text(
                                        text = if (role.isPubliclyVisible) "PUBLIC" else "HIDDEN",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (role.isPubliclyVisible) SuccessEmerald else ChorRed
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = role.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "10 GOLDEN RULES OF CHORIFY 2",
                    style = MaterialTheme.typography.labelLarge,
                    color = PoliceBlue,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp)),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                    )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        rulesList.forEachIndexed { index, (headline, detail) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(RajaGold.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${index + 1}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = RajaGold
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = headline,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = detail,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary,
                                        modifier = Modifier.padding(top = 2.dp)
                                    )
                                }
                            }
                            if (index < rulesList.lastIndex) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun MatchHistoryScreen(
    matches: List<MatchRecordEntity>,
    animationsEnabled: Boolean,
    onClearHistory: () -> Unit,
    onBackClick: () -> Unit
) {
    BackHandler(onBack = onBackClick)

    val dateFormatter = remember {
        SimpleDateFormat("MMM dd, yyyy • hh:mm a", Locale.getDefault())
    }

    CinematicBackground(animationsEnabled = animationsEnabled) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopGameBar(
                title = stringResource(R.string.btn_match_history),
                subtitle = "${matches.size} RECORDED MATCHES",
                onBackClick = onBackClick
            )

            if (matches.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.widthIn(max = 420.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .background(RajaGold.copy(alpha = 0.14f))
                                .border(1.5.dp, RajaGold.copy(alpha = 0.5f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = null,
                                tint = RajaGold,
                                modifier = Modifier.size(40.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "NO CHRONICLES RECORDED",
                            style = MaterialTheme.typography.headlineLarge,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = stringResource(R.string.history_empty),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .widthIn(max = 560.dp)
                        .weight(1f)
                        .padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(matches, key = { it.id }) { match ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp)),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
                            )
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = dateFormatter.format(Date(match.timestamp)),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = TextSecondary
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(50))
                                            .background(PoliceBlue.copy(alpha = 0.16f))
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "${match.totalRounds} ROUNDS • ${match.timerSeconds}s",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = PoliceBlue
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = "Champion",
                                        tint = RajaGold,
                                        modifier = Modifier.size(26.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "CHAMPION: ${match.championName} (${match.championScore} pts)",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = RajaGold
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                                Spacer(modifier = Modifier.height(10.dp))

                                val scoresText = "${match.player1Name}: ${match.player1Score}  •  " +
                                    "${match.player2Name}: ${match.player2Score}  •  " +
                                    "${match.player3Name}: ${match.player3Score}  •  " +
                                    "${match.player4Name}: ${match.player4Score}"
                                Text(
                                    text = scoresText,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary
                                )
                            }
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .widthIn(max = 560.dp)
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    GlassSecondaryButton(
                        text = stringResource(R.string.btn_clear_history),
                        onClick = onClearHistory,
                        icon = Icons.Default.DeleteForever,
                        borderColor = ChorRed.copy(alpha = 0.7f),
                        textColor = ChorRed,
                        testTag = "btn_clear_history"
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    settings: GameSettings,
    hasHistory: Boolean,
    onToggleSound: (Boolean) -> Unit,
    onToggleVibration: (Boolean) -> Unit,
    onToggleAnimations: (Boolean) -> Unit,
    onSelectTheme: (AppThemeOption) -> Unit,
    onClearHistory: () -> Unit,
    onBackClick: () -> Unit
) {
    BackHandler(onBack = onBackClick)

    CinematicBackground(animationsEnabled = settings.animationsEnabled) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopGameBar(
                title = stringResource(R.string.btn_settings),
                subtitle = "AUDIO, HAPTICS & COURT PALETTE",
                onBackClick = onBackClick
            )

            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp)),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                    )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        SettingToggleRow(
                            icon = Icons.Default.VolumeUp,
                            title = "Sound Effects",
                            subtitle = "Procedural royal chimes & suspense audio cues",
                            checked = settings.soundEnabled,
                            onCheckedChange = onToggleSound,
                            testTag = "switch_sound"
                        )
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                        SettingToggleRow(
                            icon = Icons.Default.Vibration,
                            title = "Haptic Vibration",
                            subtitle = "Tactile feedback on role reveal, timer & verdict",
                            checked = settings.vibrationEnabled,
                            onCheckedChange = onToggleVibration,
                            testTag = "switch_vibration"
                        )
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                        SettingToggleRow(
                            icon = Icons.Default.Animation,
                            title = "Cinematic Animations",
                            subtitle = "3D card flips, score counting & background aura",
                            checked = settings.animationsEnabled,
                            onCheckedChange = onToggleAnimations,
                            testTag = "switch_animations"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Theme Selection
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp)),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                    )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Palette,
                                contentDescription = null,
                                tint = RajaGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ROYAL COURT THEME",
                                style = MaterialTheme.typography.labelLarge,
                                color = RajaGold
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        AppThemeOption.entries.forEach { option ->
                            val isSelected = settings.themeOption == option
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 5.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        if (isSelected) RajaGold.copy(alpha = 0.16f)
                                        else Color.Black.copy(alpha = 0.22f)
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelected) RajaGold else MaterialTheme.colorScheme.outline,
                                        RoundedCornerShape(14.dp)
                                    )
                                    .clickable { onSelectTheme(option) }
                                    .padding(14.dp)
                                    .testTag("theme_option_${option.name}"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = option.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = if (isSelected) RajaGold else TextPrimary
                                    )
                                    Text(
                                        text = option.subtitle,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary
                                    )
                                }
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Selected Theme",
                                        tint = RajaGold
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                GlassSecondaryButton(
                    text = stringResource(R.string.btn_clear_history),
                    onClick = onClearHistory,
                    icon = Icons.Default.DeleteForever,
                    borderColor = if (hasHistory) ChorRed else MaterialTheme.colorScheme.outline,
                    textColor = if (hasHistory) ChorRed else TextSecondary,
                    testTag = "settings_clear_history_btn"
                )

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(RajaGold.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = RajaGold,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF0B0D17),
                checkedTrackColor = RajaGold
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}
