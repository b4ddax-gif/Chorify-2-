package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Midnight Obsidian Palette
val MidnightBg = Color(0xFF0B0D17)
val MidnightSurface = Color(0xFF131728)
val MidnightCard = Color(0xFF1A2038)
val MidnightCardElevated = Color(0xFF232B4A)
val MidnightBorder = Color(0xFF2E385C)

// Royal Crimson Palette
val CrimsonBg = Color(0xFF14080E)
val CrimsonSurface = Color(0xFF200E18)
val CrimsonCard = Color(0xFF2C1422)
val CrimsonCardElevated = Color(0xFF3B1C2E)
val CrimsonBorder = Color(0xFF562842)

// Imperial Emerald Palette
val EmeraldBg = Color(0xFF071410)
val EmeraldSurface = Color(0xFF0E211B)
val EmeraldCard = Color(0xFF163028)
val EmeraldCardElevated = Color(0xFF1F4237)
val EmeraldBorder = Color(0xFF2E5E4F)

// Role Identity Colors
val RajaGold = Color(0xFFFFC83B)
val RajaGoldDark = Color(0xFFB8860B)
val RajaGoldSurface = Color(0xFF2D230E)

val PoliceBlue = Color(0xFF38BDF8)
val PoliceBlueDark = Color(0xFF0284C7)
val PoliceBlueSurface = Color(0xFF0C2538)

val MantriSilver = Color(0xFFE2E8F0)
val MantriSilverDark = Color(0xFF94A3B8)
val MantriSilverSurface = Color(0xFF1E2532)

val ChorRed = Color(0xFFFB7185)
val ChorRedBright = Color(0xFFF43F5E)
val ChorRedDark = Color(0xFF9F1239)
val ChorRedSurface = Color(0xFF2E1019)

// Status & Accent Colors
val SuccessEmerald = Color(0xFF34D399)
val DangerCrimson = Color(0xFFF43F5E)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
