package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LocalPolice
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Role
import com.example.ui.theme.ChorRed
import com.example.ui.theme.ChorRedDark
import com.example.ui.theme.ChorRedSurface
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MantriSilver
import com.example.ui.theme.MantriSilverDark
import com.example.ui.theme.MantriSilverSurface
import com.example.ui.theme.PoliceBlue
import com.example.ui.theme.PoliceBlueDark
import com.example.ui.theme.PoliceBlueSurface
import com.example.ui.theme.RajaGold
import com.example.ui.theme.RajaGoldDark
import com.example.ui.theme.RajaGoldSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class RoleVisualStyle(
    val primaryColor: Color,
    val secondaryColor: Color,
    val surfaceColor: Color,
    val icon: ImageVector,
    val badgeLabel: String
)

fun Role.visualStyle(): RoleVisualStyle = when (this) {
    Role.RAJA -> RoleVisualStyle(
        primaryColor = RajaGold,
        secondaryColor = RajaGoldDark,
        surfaceColor = RajaGoldSurface,
        icon = Icons.Default.EmojiEvents,
        badgeLabel = "ROYAL SOVEREIGN • PUBLIC"
    )
    Role.POLICE -> RoleVisualStyle(
        primaryColor = PoliceBlue,
        secondaryColor = PoliceBlueDark,
        surfaceColor = PoliceBlueSurface,
        icon = Icons.Default.LocalPolice,
        badgeLabel = "CHIEF INVESTIGATOR • PUBLIC"
    )
    Role.MANTRI -> RoleVisualStyle(
        primaryColor = MantriSilver,
        secondaryColor = MantriSilverDark,
        surfaceColor = MantriSilverSurface,
        icon = Icons.Default.Psychology,
        badgeLabel = "ROYAL ADVISOR • SECRET"
    )
    Role.CHOR -> RoleVisualStyle(
        primaryColor = ChorRed,
        secondaryColor = ChorRedDark,
        surfaceColor = ChorRedSurface,
        icon = Icons.Default.VisibilityOff,
        badgeLabel = "SHADOW THIEF • SECRET"
    )
}

@Composable
fun CinematicBackground(
    animationsEnabled: Boolean,
    accentColor: Color = RajaGold,
    secondaryAccent: Color = PoliceBlue,
    content: @Composable () -> Unit
) {
    val bgColor = MaterialTheme.colorScheme.background
    val transition = rememberInfiniteTransition(label = "bgGlow")
    val pulse by transition.animateFloat(
        initialValue = 0.14f,
        targetValue = if (animationsEnabled) 0.26f else 0.14f,
        animationSpec = infiniteRepeatable(
            animation = tween(3600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(accentColor.copy(alpha = pulse), Color.Transparent),
                        center = Offset(size.width * 0.85f, size.height * 0.12f),
                        radius = size.width * 0.75f
                    ),
                    center = Offset(size.width * 0.85f, size.height * 0.12f),
                    radius = size.width * 0.75f
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(secondaryAccent.copy(alpha = pulse * 0.8f), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.88f),
                        radius = size.width * 0.75f
                    ),
                    center = Offset(size.width * 0.15f, size.height * 0.88f),
                    radius = size.width * 0.75f
                )
            }
    ) {
        content()
    }
}

@Composable
fun TopGameBar(
    title: String,
    subtitle: String? = null,
    onBackClick: (() -> Unit)? = null,
    backTestTag: String = "back_button",
    trailingBadge: String? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            if (onBackClick != null) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f))
                        .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                        .testTag(backTestTag)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Navigate back",
                        tint = TextPrimary
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
            }
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineLarge,
                    color = TextPrimary
                )
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelMedium,
                        color = RajaGold
                    )
                }
            }
        }

        if (trailingBadge != null) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(RajaGold.copy(alpha = 0.15f))
                    .border(1.dp, RajaGold.copy(alpha = 0.5f), RoundedCornerShape(50))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = trailingBadge,
                    style = MaterialTheme.typography.labelMedium,
                    color = RajaGold
                )
            }
        }
    }
}

@Composable
fun GoldPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    accentColor: Color = RajaGold,
    contentColor: Color = Color(0xFF0B0D17),
    testTag: String? = null
) {
    val finalModifier = if (testTag != null) modifier.testTag(testTag) else modifier
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = accentColor,
            contentColor = contentColor,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            disabledContentColor = TextMuted
        ),
        modifier = finalModifier
            .fillMaxWidth()
            .height(58.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.2.sp
                )
            )
        }
    }
}

@Composable
fun GlassSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    borderColor: Color = MaterialTheme.colorScheme.outline,
    textColor: Color = TextPrimary,
    testTag: String? = null
) {
    val finalModifier = if (testTag != null) modifier.testTag(testTag) else modifier
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.5.dp, borderColor),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
            contentColor = textColor
        ),
        modifier = finalModifier
            .fillMaxWidth()
            .height(54.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = RajaGold,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 1.sp)
            )
        }
    }
}

@Composable
fun RoleIdentityCard(
    role: Role,
    playerName: String,
    cornerLabel: String,
    modifier: Modifier = Modifier
) {
    val style = role.visualStyle()
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 2.dp,
                brush = Brush.linearGradient(
                    colors = listOf(style.primaryColor, style.secondaryColor)
                ),
                shape = RoundedCornerShape(24.dp)
            ),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = style.surfaceColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(style.primaryColor.copy(alpha = 0.16f))
                    .border(1.dp, style.primaryColor.copy(alpha = 0.5f), RoundedCornerShape(50))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = style.badgeLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = style.primaryColor
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Box(
                modifier = Modifier
                    .size(92.dp)
                    .clip(CircleShape)
                    .background(style.primaryColor.copy(alpha = 0.18f))
                    .border(2.dp, style.primaryColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = role.emoji,
                    fontSize = 44.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = role.displayName,
                style = MaterialTheme.typography.displayMedium,
                color = style.primaryColor
            )

            Text(
                text = role.tagline,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Black.copy(alpha = 0.28f))
                    .padding(14.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$playerName • $cornerLabel",
                        style = MaterialTheme.typography.labelMedium,
                        color = style.primaryColor
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = role.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun SelectableOptionChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String? = null
) {
    val bg = if (selected) RajaGold else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (selected) Color(0xFF0B0D17) else TextPrimary
    val border = if (selected) RajaGold else MaterialTheme.colorScheme.outline

    val finalMod = if (testTag != null) modifier.testTag(testTag) else modifier
    Box(
        modifier = finalMod
            .height(48.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .border(1.5.dp, border, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge.copy(
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold
            ),
            color = fg
        )
    }
}

@Composable
fun PrivacyShieldOverlay() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070910))
            .padding(32.dp)
            .testTag("privacy_shield_overlay"),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = "Privacy Shield Active",
                tint = RajaGold,
                modifier = Modifier.size(72.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "PRIVACY SHIELD ACTIVE",
                style = MaterialTheme.typography.headlineLarge,
                color = RajaGold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "All secret roles and court states are concealed while CHORIFY 2 is paused.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}
