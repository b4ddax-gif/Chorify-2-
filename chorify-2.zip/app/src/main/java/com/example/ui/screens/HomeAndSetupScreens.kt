package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDp
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.rememberTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Role
import com.example.ui.components.CinematicBackground
import com.example.ui.components.GlassSecondaryButton
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.SelectableOptionChip
import com.example.ui.components.TopGameBar
import com.example.ui.theme.ChorRed
import com.example.ui.theme.MantriSilver
import com.example.ui.theme.PoliceBlue
import com.example.ui.theme.RajaGold
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HomeScreen(
    animationsEnabled: Boolean,
    onNewGameClick: () -> Unit,
    onHowToPlayClick: () -> Unit,
    onMatchHistoryClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    // Choreographed cinematic opening sequence using Compose Transition APIs
    val entryState = remember {
        MutableTransitionState(!animationsEnabled).apply {
            targetState = true
        }
    }
    val entryTransition = rememberTransition(entryState, label = "HomeCinematicEntry")

    // Stage 1: Royal Emblem Badge & Title Header
    val headerAlpha by entryTransition.animateFloat(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 520, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "headerAlpha"
    ) { visible -> if (visible) 1f else 0f }

    val headerScale by entryTransition.animateFloat(
        transitionSpec = {
            if (animationsEnabled) {
                spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessLow
                )
            } else tween(0)
        },
        label = "headerScale"
    ) { visible -> if (visible) 1f else 0.84f }

    val headerOffsetY by entryTransition.animateDp(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 540, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "headerOffsetY"
    ) { visible -> if (visible) 0.dp else (-28).dp }

    // Stage 2: Hero Throne Room Banner with 3D Perspective Tilt
    val heroAlpha by entryTransition.animateFloat(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 580, delayMillis = 120, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "heroAlpha"
    ) { visible -> if (visible) 1f else 0f }

    val heroScale by entryTransition.animateFloat(
        transitionSpec = {
            if (animationsEnabled) {
                spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessLow
                )
            } else tween(0)
        },
        label = "heroScale"
    ) { visible -> if (visible) 1f else 0.90f }

    val heroRotationX by entryTransition.animateFloat(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 680, delayMillis = 120, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "heroRotationX"
    ) { visible -> if (visible) 0f else 16f }

    // Stage 3: Role Identity Pills Staggered Reveal inside Hero Card
    val rolePillsAlpha by entryTransition.animateFloat(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 480, delayMillis = 280, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "rolePillsAlpha"
    ) { visible -> if (visible) 1f else 0f }

    val rolePillsOffsetY by entryTransition.animateDp(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 480, delayMillis = 280, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "rolePillsOffsetY"
    ) { visible -> if (visible) 0.dp else 18.dp }

    // Stage 4: Staggered Action Buttons (New Game, How to Play, Match History, Settings)
    val btn1Alpha by entryTransition.animateFloat(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 420, delayMillis = 240, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "btn1Alpha"
    ) { visible -> if (visible) 1f else 0f }

    val btn1OffsetY by entryTransition.animateDp(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 460, delayMillis = 240, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "btn1OffsetY"
    ) { visible -> if (visible) 0.dp else 32.dp }

    val btn2Alpha by entryTransition.animateFloat(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 420, delayMillis = 320, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "btn2Alpha"
    ) { visible -> if (visible) 1f else 0f }

    val btn2OffsetY by entryTransition.animateDp(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 460, delayMillis = 320, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "btn2OffsetY"
    ) { visible -> if (visible) 0.dp else 32.dp }

    val btn3Alpha by entryTransition.animateFloat(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 420, delayMillis = 400, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "btn3Alpha"
    ) { visible -> if (visible) 1f else 0f }

    val btn3OffsetY by entryTransition.animateDp(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 460, delayMillis = 400, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "btn3OffsetY"
    ) { visible -> if (visible) 0.dp else 32.dp }

    val btn4Alpha by entryTransition.animateFloat(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 420, delayMillis = 480, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "btn4Alpha"
    ) { visible -> if (visible) 1f else 0f }

    val btn4OffsetY by entryTransition.animateDp(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 460, delayMillis = 480, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "btn4OffsetY"
    ) { visible -> if (visible) 0.dp else 32.dp }

    // Stage 5: Footer Tagline Fade
    val footerAlpha by entryTransition.animateFloat(
        transitionSpec = {
            if (animationsEnabled) tween(durationMillis = 500, delayMillis = 580, easing = FastOutSlowInEasing)
            else tween(0)
        },
        label = "footerAlpha"
    ) { visible -> if (visible) 1f else 0f }

    // Continuous Ambient Shimmer Sweep across Hero Card
    val infiniteTransition = rememberInfiniteTransition(label = "HeroAmbientShimmer")
    val shimmerSweep by infiniteTransition.animateFloat(
        initialValue = -0.6f,
        targetValue = 1.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmerSweep"
    )

    CinematicBackground(animationsEnabled = animationsEnabled) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier.widthIn(max = 560.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(8.dp))

                // Animated Header Section (Emblem Pill + Title + Subtitle)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .offset(y = headerOffsetY)
                        .graphicsLayer {
                            alpha = headerAlpha
                            scaleX = headerScale
                            scaleY = headerScale
                        }
                ) {
                    // Royal emblem pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(RajaGold.copy(alpha = 0.14f))
                            .border(1.dp, RajaGold.copy(alpha = 0.45f), RoundedCornerShape(50))
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "4-PLAYER OFFLINE DEDUCTION",
                            style = MaterialTheme.typography.labelMedium,
                            color = RajaGold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.displayLarge,
                        color = TextPrimary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("home_title")
                    )

                    Text(
                        text = stringResource(R.string.subtitle_home),
                        style = MaterialTheme.typography.labelMedium,
                        color = PoliceBlue,
                        letterSpacing = 2.5.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Hero Banner Card with 3D Entrance Tilt, Shimmer Sweep, and Role Badges Overlay
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(195.dp)
                        .graphicsLayer {
                            alpha = heroAlpha
                            scaleX = heroScale
                            scaleY = heroScale
                            rotationX = heroRotationX
                            cameraDistance = 14f * density
                        }
                        .border(
                            1.5.dp,
                            Brush.linearGradient(
                                listOf(
                                    RajaGold.copy(alpha = 0.7f),
                                    PoliceBlue.copy(alpha = 0.5f),
                                    ChorRed.copy(alpha = 0.7f)
                                )
                            ),
                            RoundedCornerShape(24.dp)
                        ),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .drawWithContent {
                                drawContent()
                                if (animationsEnabled) {
                                    val sweepCenter = size.width * shimmerSweep
                                    drawRect(
                                        brush = Brush.linearGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                RajaGold.copy(alpha = 0.12f),
                                                Color.Transparent
                                            ),
                                            start = Offset(sweepCenter - 140f, 0f),
                                            end = Offset(sweepCenter + 140f, size.height)
                                        )
                                    )
                                }
                            }
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_banner_1791448937706),
                            contentDescription = "CHORIFY 2 Royal Throne Room Banner",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            Color(0xDD0B0D17)
                                        )
                                    )
                                )
                        )
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .padding(14.dp)
                                .offset(y = rolePillsOffsetY)
                                .graphicsLayer { alpha = rolePillsAlpha },
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            RoleMiniPill(role = Role.RAJA, color = RajaGold)
                            RoleMiniPill(role = Role.POLICE, color = PoliceBlue)
                            RoleMiniPill(role = Role.MANTRI, color = MantriSilver)
                            RoleMiniPill(role = Role.CHOR, color = ChorRed)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Main Menu Action Buttons with Staggered Cascade Entry
                Box(
                    modifier = Modifier.staggeredMenuEntry(
                        alpha = btn1Alpha,
                        offsetY = btn1OffsetY
                    )
                ) {
                    GoldPrimaryButton(
                        text = stringResource(R.string.btn_new_game),
                        onClick = onNewGameClick,
                        icon = Icons.Default.PlayArrow,
                        testTag = "btn_new_game"
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier.staggeredMenuEntry(
                        alpha = btn2Alpha,
                        offsetY = btn2OffsetY
                    )
                ) {
                    GlassSecondaryButton(
                        text = stringResource(R.string.btn_how_to_play),
                        onClick = onHowToPlayClick,
                        icon = Icons.Default.MenuBook,
                        testTag = "btn_how_to_play"
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier.staggeredMenuEntry(
                        alpha = btn3Alpha,
                        offsetY = btn3OffsetY
                    )
                ) {
                    GlassSecondaryButton(
                        text = stringResource(R.string.btn_match_history),
                        onClick = onMatchHistoryClick,
                        icon = Icons.Default.History,
                        testTag = "btn_match_history"
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier.staggeredMenuEntry(
                        alpha = btn4Alpha,
                        offsetY = btn4OffsetY
                    )
                ) {
                    GlassSecondaryButton(
                        text = stringResource(R.string.btn_settings),
                        onClick = onSettingsClick,
                        icon = Icons.Default.Settings,
                        testTag = "btn_settings"
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "100% OFFLINE PASS & PLAY • ZERO ROLE LEAK ENGINE",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = footerAlpha }
            )
        }
    }
}

private fun Modifier.staggeredMenuEntry(
    alpha: Float,
    offsetY: Dp
): Modifier = this
    .fillMaxWidth()
    .offset(y = offsetY)
    .graphicsLayer {
        this.alpha = alpha
    }

@Composable
private fun RoleMiniPill(role: Role, color: Color) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0xCC131728))
            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = role.emoji, fontSize = 13.sp)
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = role.displayName,
            style = MaterialTheme.typography.labelMedium.copy(fontSize = 11.sp),
            color = color
        )
    }
}

@Composable
fun PlayerSetupScreen(
    playerNames: List<String>,
    selectedRounds: Int,
    selectedTimerSeconds: Int,
    animationsEnabled: Boolean,
    onPlayerNameChange: (Int, String) -> Unit,
    onSelectRounds: (Int) -> Unit,
    onSelectTimer: (Int) -> Unit,
    onStartMatch: () -> Unit,
    onBackClick: () -> Unit
) {
    BackHandler(onBack = onBackClick)

    val cornerPositions = listOf(
        "Corner 1 • North-West",
        "Corner 2 • North-East",
        "Corner 3 • South-West",
        "Corner 4 • South-East"
    )

    CinematicBackground(animationsEnabled = animationsEnabled) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopGameBar(
                title = stringResource(R.string.setup_title),
                subtitle = "CONFIGURE 4-CORNER COURT",
                onBackClick = onBackClick
            )

            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                // Player Names Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp)),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f)
                    )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = RajaGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.setup_players_label),
                                style = MaterialTheme.typography.labelLarge,
                                color = RajaGold
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        playerNames.forEachIndexed { index, name ->
                            OutlinedTextField(
                                value = name,
                                onValueChange = { onPlayerNameChange(index, it) },
                                singleLine = true,
                                label = {
                                    Text(
                                        text = cornerPositions[index],
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                },
                                leadingIcon = {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(RajaGold.copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${index + 1}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = RajaGold
                                        )
                                    }
                                },
                                keyboardOptions = KeyboardOptions(
                                    capitalization = KeyboardCapitalization.Words,
                                    imeAction = if (index < 3) ImeAction.Next else ImeAction.Done
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = RajaGold,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                                    focusedLabelColor = RajaGold,
                                    unfocusedLabelColor = TextSecondary,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = if (index < 3) 10.dp else 0.dp)
                                    .testTag("player_name_input_${index + 1}")
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Rounds Selection Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp)),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f)
                    )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = stringResource(R.string.setup_rounds_label),
                            style = MaterialTheme.typography.labelLarge,
                            color = RajaGold
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            listOf(3, 5, 10).forEach { rounds ->
                                SelectableOptionChip(
                                    label = "$rounds ROUNDS",
                                    selected = selectedRounds == rounds,
                                    onClick = { onSelectRounds(rounds) },
                                    modifier = Modifier.weight(1f),
                                    testTag = "rounds_option_$rounds"
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Timer Selection Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp)),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f)
                    )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = PoliceBlue,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.setup_timer_label),
                                style = MaterialTheme.typography.labelLarge,
                                color = PoliceBlue
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            listOf(15, 30, 60).forEach { sec ->
                                SelectableOptionChip(
                                    label = "${sec}s",
                                    selected = selectedTimerSeconds == sec,
                                    onClick = { onSelectTimer(sec) },
                                    modifier = Modifier.weight(1f),
                                    testTag = "timer_option_$sec"
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                GoldPrimaryButton(
                    text = stringResource(R.string.btn_start_match),
                    onClick = onStartMatch,
                    icon = Icons.Default.PlayArrow,
                    testTag = "btn_start_match"
                )

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
