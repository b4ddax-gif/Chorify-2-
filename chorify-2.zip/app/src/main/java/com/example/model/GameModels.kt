package com.example.model

enum class Role(
    val displayName: String,
    val emoji: String,
    val tagline: String,
    val description: String,
    val isPubliclyVisible: Boolean
) {
    RAJA(
        displayName = "RAJA",
        emoji = "👑",
        tagline = "The Sovereign Monarch",
        description = "Your royal identity is publicly known to all players. You automatically earn +1000 points every round.",
        isPubliclyVisible = true
    ),
    POLICE(
        displayName = "POLICE",
        emoji = "🕵️",
        tagline = "The Royal Investigator",
        description = "Your badge is publicly known to all players. Observe the hidden players and catch the Chor to earn +500 points!",
        isPubliclyVisible = true
    ),
    MANTRI(
        displayName = "MANTRI",
        emoji = "🧠",
        tagline = "The Silent Advisor",
        description = "Your identity is strictly hidden! Maintain your composure so the Police does not mistake you for the Chor. You always earn +300 points.",
        isPubliclyVisible = false
    ),
    CHOR(
        displayName = "CHOR",
        emoji = "🥷",
        tagline = "The Shadow Thief",
        description = "Your identity is strictly hidden! Blend in with the Mantri and deceive the Police. Escape detection to steal +500 points!",
        isPubliclyVisible = false
    )
}

enum class AppThemeOption(val title: String, val subtitle: String) {
    MIDNIGHT_OBSIDIAN("Midnight Obsidian", "Deep sapphire & gold royal night"),
    ROYAL_CRIMSON("Royal Crimson", "Velvet crimson & золотой palace"),
    IMPERIAL_EMERALD("Imperial Emerald", "Dark emerald & gilded court")
}

data class Player(
    val id: Int, // 0, 1, 2, 3
    val name: String,
    val cornerLabel: String,
    val totalScore: Int = 0,
    val roundsWon: Int = 0, // Count of rounds where player achieved maximum possible role outcome (Raja, Mantri, Police catch, or Chor escape)
    val policeSuccessCount: Int = 0,
    val chorEscapeCount: Int = 0
)

data class PlayerRoundResult(
    val playerId: Int,
    val playerName: String,
    val cornerLabel: String,
    val role: Role,
    val roundPoints: Int,
    val totalPointsAfterRound: Int
)

data class RoundSummary(
    val roundNumber: Int,
    val totalRounds: Int,
    val policePlayerId: Int,
    val policePlayerName: String,
    val rajaPlayerId: Int,
    val rajaPlayerName: String,
    val selectedSuspectId: Int,
    val selectedSuspectName: String,
    val actualChorId: Int,
    val actualChorName: String,
    val actualMantriId: Int,
    val actualMantriName: String,
    val chorCaught: Boolean,
    val timedOut: Boolean,
    val playerResults: List<PlayerRoundResult>
)

enum class GameScreen {
    HOME,
    PLAYER_SETUP,
    SECRET_ROLE_PASS,
    PUBLIC_ROLE_DISPLAY,
    POLICE_GUESS,
    ROUND_RESULT,
    SCOREBOARD,
    FINAL_RESULT,
    HOW_TO_PLAY,
    MATCH_HISTORY,
    SETTINGS
}

data class GameSettings(
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val animationsEnabled: Boolean = true,
    val themeOption: AppThemeOption = AppThemeOption.MIDNIGHT_OBSIDIAN
)

/**
 * Pure deterministic scoring and role distribution engine for CHORIFY 2.
 *
 * FIXED GAME RULES:
 * - RAJA = +1000 always
 * - MANTRI = +300 always
 * - If Police catches Chor: Police = +500, Chor = +0
 * - If Chor escapes: Police = +0, Chor = +500
 */
object GameRulesEngine {

    fun distributeRoles(
        playerIds: List<Int> = listOf(0, 1, 2, 3),
        random: kotlin.random.Random = kotlin.random.Random.Default
    ): Map<Int, Role> {
        require(playerIds.size == 4 && playerIds.distinct().size == 4) {
            "Exactly 4 distinct players are required."
        }
        val shuffledRoles = Role.entries.toList().shuffled(random)
        return playerIds.zip(shuffledRoles).toMap()
    }

    fun calculatePointsForRole(role: Role, chorCaught: Boolean): Int {
        return when (role) {
            Role.RAJA -> 1000
            Role.MANTRI -> 300
            Role.POLICE -> if (chorCaught) 500 else 0
            Role.CHOR -> if (chorCaught) 0 else 500
        }
    }

    fun evaluateRound(
        roundNumber: Int,
        totalRounds: Int,
        players: List<Player>,
        roleAssignments: Map<Int, Role>,
        selectedSuspectId: Int,
        timedOut: Boolean = false
    ): Pair<RoundSummary, List<Player>> {
        val actualChorId = roleAssignments.entries.first { it.value == Role.CHOR }.key
        val actualMantriId = roleAssignments.entries.first { it.value == Role.MANTRI }.key
        val policePlayerId = roleAssignments.entries.first { it.value == Role.POLICE }.key
        val rajaPlayerId = roleAssignments.entries.first { it.value == Role.RAJA }.key

        val chorCaught = selectedSuspectId == actualChorId

        val updatedPlayers = mutableListOf<Player>()
        val playerResults = mutableListOf<PlayerRoundResult>()

        for (player in players) {
            val role = roleAssignments[player.id]
                ?: error("Missing role assignment for player ${player.id}")
            val roundPoints = calculatePointsForRole(role, chorCaught)
            val newTotal = player.totalScore + roundPoints

            val wonRoundEffort = when (role) {
                Role.RAJA -> true
                Role.MANTRI -> true
                Role.POLICE -> chorCaught
                Role.CHOR -> !chorCaught
            }

            val updatedPlayer = player.copy(
                totalScore = newTotal,
                roundsWon = player.roundsWon + if (wonRoundEffort) 1 else 0,
                policeSuccessCount = player.policeSuccessCount + if (role == Role.POLICE && chorCaught) 1 else 0,
                chorEscapeCount = player.chorEscapeCount + if (role == Role.CHOR && !chorCaught) 1 else 0
            )
            updatedPlayers.add(updatedPlayer)

            playerResults.add(
                PlayerRoundResult(
                    playerId = player.id,
                    playerName = player.name,
                    cornerLabel = player.cornerLabel,
                    role = role,
                    roundPoints = roundPoints,
                    totalPointsAfterRound = newTotal
                )
            )
        }

        val suspectName = players.firstOrNull { it.id == selectedSuspectId }?.name ?: "None"
        val summary = RoundSummary(
            roundNumber = roundNumber,
            totalRounds = totalRounds,
            policePlayerId = policePlayerId,
            policePlayerName = players.first { it.id == policePlayerId }.name,
            rajaPlayerId = rajaPlayerId,
            rajaPlayerName = players.first { it.id == rajaPlayerId }.name,
            selectedSuspectId = selectedSuspectId,
            selectedSuspectName = suspectName,
            actualChorId = actualChorId,
            actualChorName = players.first { it.id == actualChorId }.name,
            actualMantriId = actualMantriId,
            actualMantriName = players.first { it.id == actualMantriId }.name,
            chorCaught = chorCaught,
            timedOut = timedOut,
            playerResults = playerResults.sortedByDescending { it.totalPointsAfterRound }
        )

        return summary to updatedPlayers
    }
}
