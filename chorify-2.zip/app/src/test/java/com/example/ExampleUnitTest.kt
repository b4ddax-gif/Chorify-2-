package com.example

import com.example.model.GameRulesEngine
import com.example.model.Player
import com.example.model.Role
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class ExampleUnitTest {

    private val basePlayers = listOf(
        Player(id = 0, name = "Player 1", cornerLabel = "Corner 1"),
        Player(id = 1, name = "Player 2", cornerLabel = "Corner 2"),
        Player(id = 2, name = "Player 3", cornerLabel = "Corner 3"),
        Player(id = 3, name = "Player 4", cornerLabel = "Corner 4")
    )

    @Test
    fun `role distribution assigns exactly one Raja, Police, Mantri, and Chor without duplicates`() {
        val random = Random(42)
        repeat(100) {
            val rolesMap = GameRulesEngine.distributeRoles(listOf(0, 1, 2, 3), random)
            assertEquals(4, rolesMap.size)
            val assignedRoles = rolesMap.values.toList()
            assertEquals(1, assignedRoles.count { it == Role.RAJA })
            assertEquals(1, assignedRoles.count { it == Role.POLICE })
            assertEquals(1, assignedRoles.count { it == Role.MANTRI })
            assertEquals(1, assignedRoles.count { it == Role.CHOR })
        }
    }

    @Test
    fun `roles reshuffle across multiple rounds`() {
        val random = Random(999)
        val distinctOrders = mutableSetOf<List<Role>>()
        repeat(30) {
            val rolesMap = GameRulesEngine.distributeRoles(listOf(0, 1, 2, 3), random)
            distinctOrders.add(listOf(rolesMap[0]!!, rolesMap[1]!!, rolesMap[2]!!, rolesMap[3]!!))
        }
        assertTrue("Roles should vary across rounds", distinctOrders.size > 1)
    }

    @Test
    fun `police selects actual Chor - awards Raja 1000, Police 500, Mantri 300, Chor 0`() {
        val fixedRoles = mapOf(
            0 to Role.RAJA,
            1 to Role.POLICE,
            2 to Role.MANTRI,
            3 to Role.CHOR
        )

        val (summary, updatedPlayers) = GameRulesEngine.evaluateRound(
            roundNumber = 1,
            totalRounds = 3,
            players = basePlayers,
            roleAssignments = fixedRoles,
            selectedSuspectId = 3 // Actual Chor
        )

        assertTrue(summary.chorCaught)
        val scoreById = updatedPlayers.associate { it.id to it.totalScore }
        assertEquals(1000, scoreById[0]) // Raja
        assertEquals(500, scoreById[1])  // Police
        assertEquals(300, scoreById[2])  // Mantri
        assertEquals(0, scoreById[3])    // Chor
    }

    @Test
    fun `police selects any non-Chor - awards Raja 1000, Police 0, Mantri 300, Chor 500`() {
        val fixedRoles = mapOf(
            0 to Role.RAJA,
            1 to Role.POLICE,
            2 to Role.MANTRI,
            3 to Role.CHOR
        )

        // Test selecting Mantri (id = 2), Raja (id = 0), and Police (id = 1)
        for (wrongSuspectId in listOf(0, 1, 2)) {
            val (summary, updatedPlayers) = GameRulesEngine.evaluateRound(
                roundNumber = 1,
                totalRounds = 3,
                players = basePlayers,
                roleAssignments = fixedRoles,
                selectedSuspectId = wrongSuspectId
            )

            assertFalse("Selecting player $wrongSuspectId should be a wrong guess", summary.chorCaught)
            val scoreById = updatedPlayers.associate { it.id to it.totalScore }
            assertEquals(1000, scoreById[0]) // Raja
            assertEquals(0, scoreById[1])    // Police
            assertEquals(300, scoreById[2])  // Mantri
            assertEquals(500, scoreById[3])  // Chor
        }
    }

    @Test
    fun `scores accumulate accurately across multiple rounds`() {
        var currentPlayers = basePlayers

        // Round 1: Police (Player 1) catches Chor (Player 3)
        val rolesRound1 = mapOf(
            0 to Role.RAJA,
            1 to Role.POLICE,
            2 to Role.MANTRI,
            3 to Role.CHOR
        )
        val (_, afterR1) = GameRulesEngine.evaluateRound(
            roundNumber = 1,
            totalRounds = 3,
            players = currentPlayers,
            roleAssignments = rolesRound1,
            selectedSuspectId = 3
        )
        currentPlayers = afterR1

        // Round 2: Roles reshuffle; Police (Player 2) misses Chor (Player 0) by picking Mantri (Player 1)
        val rolesRound2 = mapOf(
            0 to Role.CHOR,
            1 to Role.MANTRI,
            2 to Role.POLICE,
            3 to Role.RAJA
        )
        val (_, afterR2) = GameRulesEngine.evaluateRound(
            roundNumber = 2,
            totalRounds = 3,
            players = currentPlayers,
            roleAssignments = rolesRound2,
            selectedSuspectId = 1
        )
        currentPlayers = afterR2

        val totals = currentPlayers.associate { it.id to it.totalScore }
        // Player 0: R1 Raja (1000) + R2 Chor Escape (500) = 1500
        assertEquals(1500, totals[0])
        // Player 1: R1 Police Catch (500) + R2 Mantri (300) = 800
        assertEquals(800, totals[1])
        // Player 2: R1 Mantri (300) + R2 Police Miss (0) = 300
        assertEquals(300, totals[2])
        // Player 3: R1 Chor Caught (0) + R2 Raja (1000) = 1000
        assertEquals(1000, totals[3])
    }
}
