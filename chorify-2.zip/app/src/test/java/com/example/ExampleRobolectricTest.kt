package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `app name resource is CHORIFY 2`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("CHORIFY 2", appName)
    }

    @Test
    fun `full pass and play flow conceals hidden roles publicly and computes round result`() {
        composeTestRule.waitForIdle()

        // 1. Home Screen
        composeTestRule.onNodeWithTag("home_title").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_new_game").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        // 2. Player Setup Screen -> select 3 rounds & start match
        composeTestRule.onNodeWithTag("rounds_option_3").performScrollTo().performClick()
        composeTestRule.onNodeWithTag("btn_start_match").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        // 3. Pass & Play for all 4 players
        for (i in 0..3) {
            composeTestRule.onNodeWithTag("pass_target_player_name").assertIsDisplayed()
            composeTestRule.onNodeWithTag("btn_reveal_role").performScrollTo().performClick()
            composeTestRule.waitForIdle()

            composeTestRule.onNodeWithTag("revealed_role_card").assertIsDisplayed()
            composeTestRule.onNodeWithTag("btn_hide_and_pass").performScrollTo().performClick()
            composeTestRule.waitForIdle()
        }

        // 4. Public Role Display Screen: verify "Two roles remain hidden." is shown
        composeTestRule.onNodeWithTag("public_raja_card").assertIsDisplayed()
        composeTestRule.onNodeWithTag("public_police_card").assertIsDisplayed()
        composeTestRule.onNodeWithTag("two_roles_hidden_text").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithText("Two roles remain hidden.").assertIsDisplayed()

        // Proceed to Police Guess Phase
        composeTestRule.onNodeWithTag("btn_proceed_to_guess").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        // 5. Police Guess Phase
        composeTestRule.onNodeWithTag("police_guess_header").assertIsDisplayed()
        composeTestRule.onNodeWithTag("suspect_card_0").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("btn_confirm_guess").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        // 6. Round Result Screen
        composeTestRule.onNodeWithTag("round_result_banner").assertIsDisplayed()
        composeTestRule.onNodeWithTag("actual_chor_reveal").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("actual_mantri_reveal").performScrollTo().assertIsDisplayed()

        // 7. Scoreboard Screen
        composeTestRule.onNodeWithTag("btn_view_scoreboard").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("scoreboard_table_card").assertIsDisplayed()
    }
}
